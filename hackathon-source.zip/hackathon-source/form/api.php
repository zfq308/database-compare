<?php
//======================================================================
// Settings
//======================================================================
require_once 'assets/config.php';
require_once 'admin/assets/password_compatibility_library.php';

//======================================================================
// External Access
//======================================================================

$cmd = "";
$data = "";
$user = "";
$tmp_dir = "";

if (isset($_GET['cmd'])) {
  $cmd = $_GET['cmd'];
}

if (isset($_POST['cmd'])) {
  $cmd = $_POST['cmd'];
}

if (isset($_GET['data'])) {
  $data = $_GET['data'];
}

if (isset($_POST['data'])) {
  $data = $_POST['data'];
}

if (isset($_GET['user'])) {
  $user = $_GET['user'];
}

if (isset($_POST['user'])) {
  $user = $_POST['user'];
}

if (isset($_GET['tempDir'])) {
  $tmp_dir = $_GET['tempDir'];
}

if (isset($_POST['tempDir'])) {
  $tmp_dir = $_POST['tempDir'];
}

if (isset($user)) {
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	if ($user == session_id()) {
		$user = true;
	} else {
		$user = false;
	}
} else {
	$user = false;
}

if (isset($cmd) && function_exists($cmd)) {

  if ($data == '') {
    $cmd($db, $user);
	} elseif ($tmp_dir != '') {
		$cmd($db, $data, $user, $tmp_dir);
	} else {
    $cmd($db, $data, $user);
	}

} else {
  // Direct Access
  echo 'Nope!';   
	//var_dump($_SESSION);
	
}

//======================================================================
// Functions
//======================================================================


// Public Functions
function testConnection($db) {
	try {
		$stmt = $db->query("SHOW TABLES");
		$return = $stmt->fetchAll(PDO::FETCH_ASSOC);
		echo "<pre>";
		var_dump($return);
		echo "</pre>";
	} catch(PDOException $e) {
		echo "error";
		var_dump($e);
	}
}

function getVideos($db) {
	try {
		$stmt = $db->query("SELECT * FROM videos");
		$return = $stmt->fetchAll(PDO::FETCH_ASSOC);
		echo json_encode($return);
	} catch(PDOException $e) {
		echo "error";
		var_dump($e);
	}
}

function getVideo($db, $data) {
	$stmt = $db->prepare("SELECT videos.*, IFNULL(AVG(score.average), 0) AS score, responses.* FROM videos LEFT JOIN score ON videos.id=score.response LEFT JOIN responses ON videos.id=responses.id WHERE videos.id = :id GROUP BY videos.id");
	$stmt->bindParam(':id', $data);
	try {
		$stmt->execute();
		$return = $stmt->fetch(PDO::FETCH_ASSOC);
		echo '{"status":"success", "data":' . json_encode($return) . '}';
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

// Protected Functions
function getResponses($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!" ' . $user . ' - ' . session_id() . ' }';
	} else {
		$data = explode(',', $data);
		
		if ($data[0] == 'all'){
			$stmt = $db->prepare("SELECT responses.*, IFNULL(AVG(score.average), 0) AS score, IFNULL(zero_check, 0) AS zero_check FROM responses LEFT JOIN score ON responses.id=score.response GROUP BY responses.id");
		} else {
			$id = "World " . $data[0];
			$stmt = $db->prepare("SELECT responses.*, IFNULL(AVG(score.average), 0) AS score, IFNULL(zero_check, 0) AS zero_check FROM responses LEFT JOIN score ON responses.id=score.response WHERE responses.statement = :id AND responses.stage = :stage GROUP BY responses.id");
			$stmt->bindParam(':id', $id);
			$stmt->bindParam(':stage', $data[1]);
		}
		
		if ($stmt != false) {
			try {
				$stmt->execute();
				$return = $stmt->fetchAll(PDO::FETCH_ASSOC);       
        for($i = 0; $i < count($return); ++$i){
          $return[$i]['members'] = json_decode($return[$i]['members'], true);
          $return[$i]['docs'] = json_decode($return[$i]['docs'], true);
					$return[$i]['logo'] = $return[$i]['logo'];
				}

				echo '{"status":"success", "data":' . json_encode($return) . '}';
			} catch(PDOException $e) {
				echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
			}
		}
	}
}

function getResponse($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$stmt = $db->prepare("SELECT responses.*, IFNULL(AVG(score.average), 0) AS score, IFNULL(zero_check, 0) AS zero_check FROM responses LEFT JOIN score ON responses.id=score.response WHERE responses.id = :id");
		$stmt->bindParam(':id', $data);
		try {
			$stmt->execute();
			$return = $stmt->fetchAll(PDO::FETCH_ASSOC);
			echo '{"status":"success", "data":' . json_encode($return) . '}';
		} catch(PDOException $e) {
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function deleteResponse($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$stmt = $db->prepare("DELETE FROM responses WHERE id = :id");
		$stmt->bindParam(':id', $data);
		try {
			
			$dir = 'upload/' . $data;
			if (file_exists($dir)) {
				$it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
				$files = new RecursiveIteratorIterator($it,
										 RecursiveIteratorIterator::CHILD_FIRST);
				foreach($files as $file) {
						if ($file->isDir()){
								rmdir($file->getRealPath());
						} else {
								unlink($file->getRealPath());
						}
				}
				rmdir($dir);
			}
			
			$stmt->execute();
			echo '{"status":"success", "data":"Delete successful!"}';
		} catch(PDOException $e) {
			$db->rollBack();
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function pushResponse($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$data = explode(',', $data);
		$stmt = $db->prepare("UPDATE responses SET stage = :stage WHERE id = :id");
		$stmt->bindParam(':id', $data[1]);
		$stmt->bindParam(':stage', $data[0]);
		$reset = 'success';
		
		if ($data[0] == "4") {
			$reset = resetScore($db, $data[1]);
			$reset = json_decode($reset);
			$reset = $reset->status;
		}

		if ($reset == 'success') {
			try {
				$stmt->execute();
				echo '{"status":"success", "data":"Push successful!"}';
			} catch(PDOException $e) {
				$db->rollBack();
				echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
			}
		} else {
			echo '{"status":"error", "data":"Sorry, there was a problem while pushing the response, please try again."}';
		}
	}
}

function resetScore($db, $data) {
	$stmt = $db->prepare("DELETE FROM score WHERE response = :id");
	$stmt->bindParam(':id', $data);

	try {
		$stmt->execute();
		return '{"status":"success", "data":"Score resetted!"}';
	} catch(PDOException $e) {
		$db->rollBack();
		return '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

//internal function used be vote()
function extendSession($db, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$_SESSION['last_activity'] = time(); // update last activity time stamp
		echo '{"status":"success", "data":"Session extended!"}';
	}
}

function getNotes($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$stmt = $db->prepare("SELECT notes.note_content, notes.note_created, users.user_name FROM notes INNER JOIN users WHERE notes.user_id = users.user_id AND response_id = :response_id ORDER BY notes.note_created DESC");
		$stmt->bindParam(':response_id', $data, PDO::PARAM_INT);

		try {
			$stmt->execute();
			$return = $stmt->fetchAll(PDO::FETCH_ASSOC);
			echo '{"status":"success", "data":' . json_encode($return) . '}';
		} catch(PDOException $e) {
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function addNote($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {	
		$stmt = $db->prepare("INSERT INTO notes (note_content, user_id, response_id) VALUES (:note_content, :user_id, :response_id)");
		$stmt->bindParam(':note_content', $data[0]);
		$stmt->bindParam(':user_id', $_SESSION["user_id"]);
		$stmt->bindParam(':response_id', $data[1]);
		
		try {
			$stmt->execute();
			echo '{"status":"success", "data":"Note added!"}';
		} catch(PDOException $e) {
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function getUsers($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$data = explode(", ",$data);
		
		if ($data[0] == 'all') {
			$stmt = $db->prepare("SELECT users.user_id, users.user_name, users.user_email, users.user_group, users.user_role, groups.group_name FROM users INNER JOIN groups WHERE users.user_group = groups.group_id");
		} elseif ($data[0] == 'group') {
			$stmt = $db->prepare("SELECT * FROM users WHERE user_group=:user_group");
			$stmt->bindParam(':user_group', $data[1], PDO::PARAM_INT);
		} else {
			$stmt = false;
			echo '{"status":"error", "data":"ID not valid!"}';
		}

		if ($stmt != false) {
			try {
				$stmt->execute();
				$return = $stmt->fetchAll(PDO::FETCH_ASSOC);
				echo '{"status":"success", "data":' . json_encode($return) . '}';
			} catch(PDOException $e) {
				echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
			}
		}
	}
}

function addUser($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$data = json_decode($data);
		if (checkRegistrationData($data, 'new')) {
			$stmt = $db->prepare("INSERT INTO users (user_name, user_password_hash, user_email,	user_group, user_role) VALUES (:user_name, :user_password_hash, :user_email, :user_group, :user_role)");

			$user_name = htmlentities($data[0]->value, ENT_QUOTES);
			$user_email = htmlentities($data[1]->value, ENT_QUOTES);
			$user_password = $data[2]->value;
			$user_password_hash = password_hash($user_password, PASSWORD_DEFAULT);

			$stmt->bindParam(':user_name', $user_name);
			$stmt->bindParam(':user_password_hash', $user_password_hash);
			$stmt->bindParam(':user_email', $user_email);
			$stmt->bindParam(':user_group', $data[4]->value);
			$stmt->bindParam(':user_role', $data[5]->value);
			
			try {
				$stmt->execute();
				echo '{"status":"success", "data":"User Added!"}';
			} catch(PDOException $e) {
				if ($stmt->errorInfo()[1] == 1062) {
					echo '{"status":"error", "data":"Username or Email has already been used. <br /><br /> DB Error - ' . $stmt->errorInfo()[2] . '"}';	
				} else {
					echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
				}
			}
			
		} else {
			echo '{"status":"error", "data":"Input Error - Entered data was not validated!"}';
		}
	}
}

function deleteUser($db, $data, $user) {
	$user_group = $_SESSION['user_group'];
	if (!$user || $user_group != '1') {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$stmt = $db->prepare("DELETE FROM users WHERE user_id = :user_id");
		$stmt->bindParam(':user_id', $data);
		try {
			$stmt->execute();
			echo '{"status":"success", "data":"User Deleted!"}';
		} catch(PDOException $e) {
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function updateUser($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$user_group = $_SESSION['user_group'];
		$data = json_decode($data);
		
		if ($data[2]->value == '') {
			$type = 'update';
		} else {
			$type = 'new';
		}
		
		if (checkRegistrationData($data, $type) && ($user_group == '1')) {
			if ($type == 'new') {
				$stmt = $db->prepare("UPDATE users SET user_name = :user_name, user_password_hash = :user_password_hash, user_email = :user_email, user_group = :user_group WHERE user_id = :user_id");

				$user_name = htmlentities($data[0]->value, ENT_QUOTES);
				$user_email = htmlentities($data[1]->value, ENT_QUOTES);
				$user_password = $data[2]->value;
				$user_password_hash = password_hash($user_password, PASSWORD_DEFAULT);

				$stmt->bindParam(':user_name', $user_name);
				$stmt->bindParam(':user_password_hash', $user_password_hash);
				$stmt->bindParam(':user_email', $user_email);
				$stmt->bindParam(':user_group', $data[4]->value);
				$stmt->bindParam(':user_id', $data[5]->value);
			}
			
			if ($type == 'update') {
				$stmt = $db->prepare("UPDATE users SET user_name = :user_name, user_email = :user_email,	user_group = :user_group WHERE user_id = :user_id");

				$user_name = htmlentities($data[0]->value, ENT_QUOTES);
				$user_email = htmlentities($data[1]->value, ENT_QUOTES);
				$user_password = $data[2]->value;
	
				$stmt->bindParam(':user_name', $user_name);
				$stmt->bindParam(':user_email', $user_email);
				$stmt->bindParam(':user_group', $data[4]->value);
				$stmt->bindParam(':user_id', $data[5]->value);
			}

			try {
				$stmt->execute();
				echo '{"status":"success", "data":"User Updated!"}';
			} catch(PDOException $e) {
				if ($stmt->errorInfo()[1] == 1062) {
					echo '{"status":"error", "data":"Username or Email has already been used. <br /><br /> DB Error - ' . $stmt->errorInfo()[2] . '"}';	
				} else {
					echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
				}
			}
			
		} else {
			echo '{"status":"error", "data":"Input Error - Entered data was not validated!"}';
		}
	}
}

function getGroups($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		if ($data == 'all') {
			$stmt = $db->prepare("SELECT * FROM groups");
		} elseif (is_int($data + 0)) {
			$stmt = $db->prepare("SELECT * FROM groups WHERE group_id=:group_id");
			$stmt->bindParam(':group_id', $data, PDO::PARAM_INT);
		} else {
			$stmt = false;
			echo '{"status":"error", "data":"ID not valid!"}';
		}

		if ($stmt != false) {
			try {
				$stmt->execute();
				$return = $stmt->fetchAll(PDO::FETCH_ASSOC);
				echo '{"status":"success", "data":' . json_encode($return) . '}';
			} catch(PDOException $e) {
				echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
			}
		}
	}
}

// function addGroup($db, $data, $user) {
// 	if (!$user) {
// 		echo '{"status":"error", "data":"Session not valid!"}';
// 	} else {
// 		$data = json_decode($data);
		
// 		$stmt = $db->prepare("INSERT INTO groups (group_name) VALUES (:group_name)");

// 		$group_name = htmlentities($data[0]->value);
// 		$stmt->bindParam(':group_name', $group_name);

// 		try {
// 			$stmt->execute();
// 			echo '{"status":"success", "data":"Group Added!"}';
// 		} catch(PDOException $e) {
// 			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
// 		}
// 	}
// }

// function deleteGroup($db, $data, $user) {
// 	$user_role = $_SESSION['user_role'];
// 	if (!$user) {
// 		echo '{"status":"error", "data":"Session not valid!"}';
// 	} else {
// 		if ($user_role == 'super_admin') {
// 			$stmt = $db->prepare("DELETE FROM groups WHERE group_id = :group_id");
// 			$stmt->bindParam(':group_id', $data);
// 		}	else {
// 			echo '{"status":"error", "data":"User Role not defined!"}';
// 		}
		
// 		try {
// 			$stmt->execute();
// 			echo '{"status":"success", "data":"Group Deleted!"}';
// 		} catch(PDOException $e) {
// 				if ($stmt->errorInfo()[1] == 1451) {
// 					echo '{"status":"error", "data":"Groups with users assigned to them cannot be deleted!"}';	
// 				} else {
// 					echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
// 				}
// 		}
// 	}
// }

function checkRegistrationData($data, $type) {
	if (!$data) {
		return false;
	}
	// validating the input
	if ($type == "new") {
		if (!empty($data[0]->value)
				&& strlen($data[0]->value) <= 64
				&& strlen($data[0]->value) >= 2
				&& preg_match('/^[a-z\d]{2,64}$/i', $data[0]->value)
				&& !empty($data[1]->value)
				&& strlen($data[1]->value) <= 64
				&& filter_var($data[1]->value, FILTER_VALIDATE_EMAIL)
				&& !empty($data[2]->value)
				&& strlen($data[2]->value) >= 6
				&& !empty($data[3]->value)
				&& ($data[2]->value === $data[3]->value)
		) {
				// only this case return true, only this case is valid
				return true;
		}
	}
	if ($type == "update") {
		if (!empty($data[0]->value)
				&& strlen($data[0]->value) <= 64
				&& strlen($data[0]->value) >= 2
				&& preg_match('/^[a-z\d]{2,64}$/i', $data[0]->value)
				&& !empty($data[1]->value)
				&& strlen($data[1]->value) <= 64
				&& filter_var($data[1]->value, FILTER_VALIDATE_EMAIL)
		) {
				// only this case return true, only this case is valid
				return true;
		}
	}
	// default return
	return false;
}

function getStats($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {
		$return = [];
		$data = explode(', ', $data);
		if ($data[0] == 'global') {
			$return[] = getApplicationCount($db, $data)[0];
			//$return[] = getChallengeCount($db, $data)[0];
			//$return[] = getMemberCount($db, $data)[0];
			$return[] = getApplicationCountByDate($db, $data);
			$return[] = getApplicationCountByChallenge($db, $data);
			//$return[] = getChallengeList($db, $data);
			$return[] = getTechCount($db, $data);
			$return[] = getParticipantCount($db, $data);
			$return[] = getParticipantCountByDate($db, $data);
			$return[] = getMarketingCount($db, $data);
			$return[] = getPersonTypeCount($db, $data);
			echo json_encode($return);
		}
		if ($data[0] == 'group') {
			$return[] = getApplicationCount($db, $data)[0];
			//$return[] = getChallengeCount($db, $data)[0];
			//$return[] = getMemberCount($db, $data)[0];
			$return[] = getApplicationCountByDate($db, $data);
			$return[] = getApplicationCountByChallenge($db, $data);
			//$return[] = getChallengeList($db, $data);
			$return[] = getTechCount($db, $data);
			$return[] = getParticipantCount($db, $data);
			$return[] = getParticipantCountByDate($db, $data);
			$return[] = getMarketingCount($db, $data);
			$return[] = getPersonTypeCount($db, $data);
			echo json_encode($return);
		}
		if ($data[0] == 'challenge') {
			$return[] = getApplicationCount($db, $data)[0];
			$return[] = getChallengeDeadline($db, $data)[0];
			$return[] = getApplicationCountByDate($db, $data);
			$votes = getVotesByChallenge($db, $data);
			
			for ($i = 1; $i <= count($votes); $i++) {
				$votes[$i-1][2] = $votes[$i-1][2];
			}

			$return[] = $votes;
			
			echo json_encode($return);
		}
	}
}

//Stats Support Functions
function getApplicationCount($db, $data) {
	if ($data[0] == 'global') {
		$stmt = $db->prepare('SELECT IFNULL(COUNT(*),  0) AS count FROM responses');
	} elseif ($data[0] == 'group') {
		$stmt = $db->prepare('SELECT IFNULL(COUNT(*),  0) AS count FROM responses WHERE location = :location');
		$stmt->bindParam(':location', $data[1]);
	} elseif ($data[0] == 'challenge')  {
		$stmt = $db->prepare('SELECT COUNT(*) FROM responses WHERE challenge_id = :challenge_id');
		$stmt->bindParam(':challenge_id', $data[1]);
	}	else {
		echo '{"status":"error", "data":"Count Filter not defined"}';
	}
		
	try {
		$stmt->execute();
		return $stmt->fetch(PDO::FETCH_NUM);
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getParticipantCount($db, $data) {
	if ($data[0] == 'global') {
		$stmt = $db->prepare('SELECT members FROM responses');
	} elseif ($data[0] == 'group') {
		$stmt = $db->prepare('SELECT members FROM responses WHERE location = :location');
		$stmt->bindParam(':location', $data[1]);
	}	else {
		echo '{"status":"error", "data":"Participant Count Filter not defined"}';
	}
		
	try {
		$stmt->execute();
		$participants = $stmt->fetchAll(PDO::FETCH_NUM);
		$participantCount = 0;
		
		foreach ($participants as $team) {
			$teamCount = count(json_decode($team[0], true));
			$participantCount += $teamCount;
		}
		
		return $participantCount;
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getParticipantCountByDate($db, $data) {
	if ($data[0] == 'global') {
		$stmt = $db->prepare("SELECT members AS participants, DATE_FORMAT(DATE_ADD(timestamp, INTERVAL(1-DAYOFWEEK(timestamp)) +8 DAY), '%d-%m-%Y') AS date FROM responses ORDER BY WEEKOFYEAR(timestamp)");
	} elseif ($data[0] == 'group') {
		$stmt = $db->prepare("SELECT members AS participants, DATE_FORMAT(DATE_ADD(timestamp, INTERVAL(1-DAYOFWEEK(timestamp)) +8 DAY), '%d-%m-%Y') AS date FROM responses WHERE location = :location ORDER BY WEEKOFYEAR(timestamp)");
		$stmt->bindParam(':location', $data[1]);
	}	else {
		echo '{"status":"error", "data":"Participant Count Filter not defined"}';
	}
		
	try {
		$stmt->execute();
		$participants = $stmt->fetchAll(PDO::FETCH_NUM);
		$count = array();
		
		foreach ($participants as $team) {
			$teamCount = count(json_decode($team[0], true));
			$team[0] = count(json_decode($team[0], true));
			
			if (isset($count[$team[1]])) {
        $count[$team[1]] += $team[0];
    	} else {
				$count[$team[1]] = 0;
        $count[$team[1]] += $team[0];
   		}
		}

		$returnArray = array();
		
		foreach ($count as $key => $value) {
			$tempArray = array();
			array_push($tempArray,$value,$key);
			array_push($returnArray,$tempArray);
		}
		
		return $returnArray;
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getMarketingCount($db, $data) {
	if ($data[0] == 'global') {
		$stmt = $db->prepare('SELECT source, COUNT(source) as count FROM responses GROUP BY source');
	} elseif ($data[0] == 'group') {
		$stmt = $db->prepare('SELECT source, COUNT(source) as count FROM responses WHERE location = :location GROUP BY source');
		$stmt->bindParam(':location', $data[1]);
	}	else {
		echo '{"status":"error", "data":"Marketing Count Filter not defined"}';
	}
		
	try {
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_NUM);
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getApplicationCountByDate($db, $data) {
	if ($data[0] == 'global') {
		$stmt = $db->prepare("SELECT COUNT(1) AS applications, DATE_FORMAT(DATE_ADD(timestamp, INTERVAL(1-DAYOFWEEK(timestamp)) +8 DAY), '%d-%m-%Y') AS date FROM responses GROUP BY date");
//		$stmt = $db->prepare("SELECT COUNT(1) AS applications, DATE_FORMAT(timestamp, '%d-%m-%Y') AS date FROM responses GROUP BY date ORDER by timestamp");
	} elseif ($data[0] == 'group') {
		$stmt = $db->prepare("SELECT COUNT(1) AS applications, DATE_FORMAT(DATE_ADD(timestamp, INTERVAL(1-DAYOFWEEK(timestamp)) +8 DAY), '%d-%m-%Y') AS date FROM responses WHERE location = :location GROUP BY date");
		$stmt->bindParam(':location', $data[1]);
	} elseif ($data[0] == 'challenge')  {
		$stmt = $db->prepare('SELECT DAY(timestamp), MONTH(timestamp), COUNT(DAY(timestamp)) FROM responses WHERE challenge_id = :challenge_id GROUP BY DAY(timestamp)');
		$stmt->bindParam(':challenge_id', $data[1]);
	}	else {
		echo '{"status":"error", "data":"Count Filter not defined"}';
	}
	
	try {
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_NUM);
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getApplicationCountByChallenge($db, $data) {
	if ($data[0] == 'global') {
		$stmt = $db->prepare('SELECT statement, COUNT(*) FROM responses GROUP BY statement');
	} elseif ($data[0] == 'group') {
		$stmt = $db->prepare('SELECT statement, COUNT(*) FROM responses WHERE location = :location GROUP BY statement');
		$stmt->bindParam(':location', $data[1]);
	} elseif ($data[0] == 'challenge')  {

	}	else {
		echo '{"status":"error", "data":"Count Filter not defined"}';
	}
	
	try {
		$stmt->execute();
		$arr = [["World 1", "0"], ["World 2", "0"], ["World 3", "0"]];
		$db_data = $stmt->fetchAll(PDO::FETCH_NUM);
		
		for ($i = 0; $i <= 2; $i++) {
			foreach ($db_data as $val) {
				if ($arr[$i][0] == $val[0]) {
					$arr[$i][1] = $val[1];
				}
			}
		}
		
		return $arr;
		
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getChallengeList($db, $data) {
	
	if ($data[0] == 'global') {
		$stmt = $db->prepare("SELECT challenge_title FROM challenges");
	} elseif ($data[0] == 'group') {
		$stmt = $db->prepare("SELECT challenge_title FROM challenges WHERE challenge_group = :group_id");
		$stmt->bindParam(':group_id', $data[1]);
	} else {
		echo '{"status":"error", "data":"ID not valid!"}';
	}

	try {
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_NUM);
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getVotesByChallenge($db, $data) {
	$stmt = $db->prepare("SELECT response_id, challenge_id, response_votes_count FROM responses WHERE challenge_id = :challenge_id");
	$stmt->bindParam(':challenge_id', $data[1]);
	
	try {
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_NUM);
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getScore($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {	
		$stmt = $db->prepare("SELECT score FROM score WHERE judge = :judge AND response = :response");
		$stmt->bindParam(':judge', $_SESSION["user_id"]);
		$stmt->bindParam(':response', $data);
		try {
			$stmt->execute();
			$return = $stmt->fetch(PDO::FETCH_NUM);
			$return = ($return[0] == '') ? '"0"' : $return[0];
			echo '{"status":"success", "data":' . $return . '}';
		} catch(PDOException $e) {
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function getScores($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {	
		$stmt = $db->prepare("SELECT user_name, score, average, zero_check, timestamp FROM score LEFT JOIN users ON score.judge=users.user_id WHERE response = :response");
		$stmt->bindParam(':response', $data);
		try {
			$stmt->execute();
			$return = $stmt->fetchAll(PDO::FETCH_ASSOC);
			echo '{"status":"success", "data":' . json_encode($return) . '}';
		} catch(PDOException $e) {
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function saveScore($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {	
		$data = explode(', ', $data);
		$check = checkScore($db, $_SESSION["user_id"], $data[0]);
		$check = $check[0];
		
		$zero_check = 0;
		
		if (in_array("0", json_decode($data[1]))) {
			$zero_check = 1;
		}
		
		if ($check == 0) {
			$stmt = $db->prepare("INSERT INTO score (judge, response, score, average, zero_check) VALUES (:judge, :response, :score, :average, :zero_check)");
		} elseif ($check == 1) {
			$stmt = $db->prepare("UPDATE score SET score = :score, average = :average, zero_check = :zero_check WHERE judge = :judge AND response = :response");
		} else {
			
		}
		
		if ($check == 0 || $check == 1) {
			$stmt->bindParam(':judge', $_SESSION["user_id"]);
			$stmt->bindParam(':response', $data[0]);
			$stmt->bindParam(':score', $data[1]);
			$stmt->bindParam(':average', $data[2]);
			$stmt->bindParam(':zero_check', $zero_check);
		}
		
		try {
			if ($check == 0 || $check == 1) {
				$stmt->execute();
				echo '{"status":"success", "data":"Score submitted!"}';
			} else {
				echo '{"status":"danger", "data":"There was an error processing your submission. ' . var_dump($check) . '"}';
			}

		} catch(PDOException $e) {
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function checkScore($db, $judge, $response) {
	$stmt = $db->prepare("SELECT COUNT(*) FROM score WHERE judge = :judge AND response = :response");
	$stmt->bindParam(':judge', $judge);
	$stmt->bindParam(':response', $response);
	try {
		$stmt->execute();
		$response = $stmt->fetch(PDO::FETCH_NUM);
	} catch(PDOException $e) {
		$response = 'Error';
	}
	return $response;
}

function saveVideo($db, $data, $user) {
	if (!$user) {
		echo '{"status":"error", "data":"Session not valid!"}';
	} else {	
		$data = explode(', ', $data);
		$check = checkVideo($db, $data[0]);
		$check = $check[0];
		
		if ($check == 0) {
			$stmt = $db->prepare("INSERT INTO videos (id, link, summary, tags, position) VALUES (:id, :link, :summary, :tags, :position)");
		} elseif ($check == 1) {
			$stmt = $db->prepare("UPDATE videos SET link = :link, summary = :summary, tags = :tags, position = :position WHERE id = :id");
		} else {
			
		}
		
		$params = array();
		parse_str($data[1], $params);
		
		if ($check == 0 || $check == 1) {
			$stmt->bindParam(':id', $data[0]);
			$stmt->bindParam(':link', $params['link']);
			$stmt->bindParam(':summary', $params['summary']);
			$stmt->bindParam(':tags', $params['tags']);
			$stmt->bindParam(':position', $params['position']);
		}
		
		try {
			if ($check == 0 || $check == 1) {
				$stmt->execute();
				echo '{"status":"success", "data":"Video added!"}';
			} else {
				echo '{"status":"danger", "data":"There was an error processing your submission. ' . var_dump($check) . '"}';
			}

		} catch(PDOException $e) {
			echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
		}
	}
}

function checkVideo($db, $id) {
	$stmt = $db->prepare("SELECT COUNT(*) FROM videos WHERE id = :id");
	$stmt->bindParam(':id', $id);
	try {
		$stmt->execute();
		$response = $stmt->fetch(PDO::FETCH_NUM);
	} catch(PDOException $e) {
		$response = 'Error';
	}
	return $response;
}

function getTechCount($db, $data) {
	if ($data[0] == 'global') {
		$stmt = $db->prepare('SELECT tech FROM responses WHERE tech <> ""');
	} elseif ($data[0] == 'group') {
		$stmt = $db->prepare('SELECT tech FROM responses WHERE tech <> "" AND location = :location');
		$stmt->bindParam(':location', $data[1]);
	} elseif ($data[0] == 'challenge')  {
		$stmt = $db->prepare('SELECT COUNT(*) FROM responses WHERE challenge_id = :challenge_id');
		$stmt->bindParam(':challenge_id', $data[1]);
	}	else {
		echo '{"status":"error", "data":"Count Filter not defined"}';
	}
		
	try {
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_NUM);
	} catch(PDOException $e) {
		echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
	}
}

function getPersonTypeCount($db, $data) {
    $barclays = 0;
    $profesional = 0;
       $student = 0;
    if ($data[0] == 'global') {
        $stmt = $db->prepare('SELECT members FROM `responses`');
        $stmt->execute();
        $return = $stmt->fetchAll(PDO::FETCH_NUM);
          foreach ($return as $i => $value){
          $array = json_decode($return[$i][0], true);
          foreach ($array as $value2){
          if ($value2["position"] == "Barclays Employee"){
          ++$barclays;
          }
          elseif ($value2["position"] == "Professional"){
          ++$profesional;
          }
          elseif ($value2["position"] == "Student"){
          ++$student;
          }
       $result = array("Barclays Employee"=>$barclays, "Professional"=>$profesional, "Student"=>$student);
        }
        
    }
} elseif ($data[0] == 'group') {
        $stmt = $db->prepare('SELECT members FROM `responses` WHERE location = :location');
        $stmt->bindParam(':location', $data[1]);
        $stmt->execute();
        $return = $stmt->fetchAll(PDO::FETCH_NUM);
          foreach ($return as $i => $value){
          $array = json_decode($return[$i][0], true);
          foreach ($array as $value2){
          if ($value2["position"] == "Barclays Employee"){
          ++$barclays;
          }
          elseif ($value2["position"] == "Professional"){
          ++$profesional;
          }
          elseif ($value2["position"] == "Student"){
          ++$student;
          }
    }    
}     $result = array("Barclays Employee"=>$barclays, "Professional"=>$profesional, "Student"=>$student);
}
else {
        echo '{"status":"error", "data":"Count Filter not defined"}';
    }
        
    try {
        return $result;
    } catch(PDOException $e) {
        echo '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
    }
}