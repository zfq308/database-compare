<!DOCTYPE html>
<html>

<head>
  <title>Hackathon Form</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.26.4/css/uikit.almost-flat.min.css" />
  <style>
    .msg {
      text-align: center;
      width: 100vw;
      height: 70vh;
      padding-top: 30vh;
      font-size: 3em;
      line-height: 1.5em;
      background-image: url(assets/img/banner-4.png);
      background-size: cover;
      background-position: center;
      color: #fff;
    }
    
    .text {
      padding: 2em;
      background: rgba(0,0,0,.75);
    }
  </style>
</head>
  
<body>
 
<?php
  
  require_once 'assets/config.php';

//   echo '<pre>';
//   ini_set('display_errors', 1);
//   ini_set('display_startup_errors', 1);
//   error_reporting(E_ALL);
//   var_dump(json_encode($_POST['tech']));
//   var_dump($_FILES); 
  
//   if(!isset($_POST["formSubmit"])) {
//     header('Location: index.html');
//   }
  
  if(!isset($_POST["help"])) {
    $_POST["help"] = '0';
  } 
  
  $logo = "";
  $docs = "";
  
  $i = 0;
  foreach ($_POST["members"] as $value) {
    if ($value['name'] == "") {
      unset($_POST["members"][$i]);
    }
    $i++;
  }
  
  if ($_FILES['logo']['name'] == "") {
    unset($_FILES['logo']);
  } else {
    $logo = $_FILES['logo']['name'];
  }
  
  if ($_FILES['docs']['name'][0] == "") {
    unset($_FILES['docs']);
  } else {
    $docs = json_encode($_FILES['docs']['name']); 
  }

  $members = json_encode($_POST["members"], JSON_FORCE_OBJECT);
  $id = base_convert(microtime(false), 10, 36);
  
  if (isset($_POST['tech'])) {
    $tech = json_encode($_POST['tech']);
  } else {
    $tech = NULL;
  }
  
  $upload_status = json_decode(uploadFiles($id), true);
    
  if ($upload_status["status"] == 'success') {
    $insert_status = json_decode(insertIntoDb($id, $members, $docs, $logo, $tech, $db), true);
  }

  if ($insert_status["status"] == 'success') {
    echo '<div class="msg"><div class="text">Your application was successfully submitted. <br> Your unique submission identifier is: <b>' . $insert_status["data"] . '</b></div></div>';
  }

  function insertIntoDb($id, $members, $docs, $logo, $tech, $db) {

    $stmt = $db->prepare("INSERT INTO responses (id, location, statement, name, logo, phone, members, idea, url, benefit, docs, source, source_other, help, tech) VALUES (:id, :location, :statement, :name, :logo, :phone, :members, :idea, :url, :benefit, :docs, :source, :other, :help, :tech)");
    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':location', $_POST["location"]);
    $stmt->bindParam(':statement', $_POST["statement"]);
    $stmt->bindParam(':name', $_POST["name"]);
    $stmt->bindParam(':logo', $logo);
    $stmt->bindParam(':phone', $_POST["phone"]);
    $stmt->bindParam(':members', $members);
    $stmt->bindParam(':idea', $_POST["idea"]);
    $stmt->bindParam(':url', $_POST["url"]);
    $stmt->bindParam(':benefit', $_POST["benefit"]);
    $stmt->bindParam(':docs', $docs);
    $stmt->bindParam(':source', $_POST["source"]);
    $stmt->bindParam(':other', $_POST["source-other"]);
    $stmt->bindParam(':help', $_POST["help"]);
    $stmt->bindParam(':tech', $tech);

    try {
      $stmt->execute();
      $response = '{"status":"success", "data":"'.$id.'"}';
    } catch(PDOException $e) {
      $response = '{"status":"error", "data":"DB Error - ' . $e->getMessage() . '"}';
    }
    
    $db = NULL;
    return $response;
  
  }

  function reArrayFiles(&$file_post) {

      $file_ary = array();
      $file_count = count($file_post['name']);
      $file_keys = array_keys($file_post);

      for ($i=0; $i<$file_count; $i++) {
          foreach ($file_keys as $key) {
              $file_ary[$i][$key] = $file_post[$key][$i];
          }
      }

      return $file_ary;
  }

  function uploadFiles($id) {   
    mkdir('upload/'.$id, 0777, true);
    if (isset($_FILES['docs'])) {
      $file_ary = reArrayFiles($_FILES['docs']);
      foreach ($file_ary as $file) {
        $msg = processImage($file, 'upload/'.$id.'/');
      }
    } else {
      $msg = '{"status":"success", "data":"No file submitted"}';
    }
    
    if (isset($_FILES['logo'])) {
      $msg = processImage($_FILES['logo'], 'upload/'.$id.'/');
      $msg = '{"status":"success", "data":"No file submitted"}';
    }
    
    return $msg;

  }
  
  function processImage($file, $target_dir) {
    $target_file = $target_dir . basename($file['name']);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

    if (file_exists($target_file)) {
        $msg = '{"status":"error", "data":"Sorry, file already exists."}';
        $uploadOk = 0;
    }

    if ($file["size"] > 20971520) {
        $msg = '{"status":"error", "data":"Sorry, your file is too large."}';
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        $msg = '{"status":"error", "data":"Sorry, your file was not uploaded."}';
    } else {
      if (move_uploaded_file($file["tmp_name"], $target_file)) {
        $msg = '{"status":"success", "data":"The file '. basename( $file["name"]). ' has been uploaded."}';
      } else {
        $msg = '{"status":"error", "data":"Sorry, there was an error uploading your file."}';
      }
    }
    
    return $msg;  
    
  }
  
?>
  
</body>