<?php require_once'assets/session.php' ?>

<!doctype html>
<html class="no-js" lang="">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Rise Challenges | Admin - Stats</title>
    <meta name="description" content="Rise Challenges">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include 'assets/header.php' ?>
  </head>
  
  <body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    
    <?php include 'assets/topbar.php' ?>
    
    <div class="uk-container stats">
      <div class="uk-grid">
        <div class="uk-width-1-1 uk-width-large-1-4">
          <h4>Total applications</h4>
          <div class="uk-grid">
            <div class="uk-width-1-2 uk-width-large-1-1 uk-margin-bottom">
              <div id="responseTotal" class="uk-panel uk-panel-box">
                <h3 class="uk-panel-title">-</h3>
                <hr>
                <img src="assets/img/icon-pencil.png" class="icon"> Applications
              </div>          
            </div>
            <div class="uk-width-1-2 uk-width-large-1-1 uk-margin-bottom">
              <div id="participantTotal" class="uk-panel uk-panel-box">
                <h3 class="uk-panel-title">-</h3>
                <hr>
                <img src="assets/img/icon-user.png" class="icon"> Participants
              </div>
            </div>
          </div>
        </div>
        <div id="barChart" class="uk-width-1-1 uk-width-large-3-4">
          <h4>Applications by statement</h4>
          <div id="responsesChallengeWrapper" class="uk-panel uk-panel-box">
            <canvas id="responsesChallenge" width="200px" height="200px"></canvas>
          </div>
        </div>
      </div>
    
      <div class="uk-grid">
        <div class="uk-width-1-1">
          <h4>Applications over time</h4>
          <div id="responsesTimeWrapper" class="uk-panel uk-panel-box">
            <canvas id="responsesTime"></canvas>
          </div>
        </div>
      </div>
      
      <div class="uk-grid">
        <div class="uk-width-1-1">
          <h4>Participants over time</h4>
          <div id="responsesParticipantsTimeWrapper" class="uk-panel uk-panel-box">
            <canvas id="responsesParticipantsTime"></canvas>
          </div>
        </div>
      </div>
    
      <div class="uk-grid uk-margin-large-bottom">
        <div class="uk-width-1-1">
          <h4>Prefered Technologies</h4>
          <div id="responsesTechWrapper" class="uk-panel uk-panel-box">
            <canvas id="responsesTech"></canvas>
          </div>
        </div>
      </div>
      
      <div class="uk-grid uk-margin-large-bottom">
        <div class="uk-width-1-1">
          <h4>Marketing Sources</h4>
          <div id="responsesMarketingWrapper" class="uk-panel uk-panel-box">
            <canvas id="responsesMarketing"></canvas>
          </div>
        </div>
      </div>
      
      <div class="uk-grid uk-margin-large-bottom">
        <div class="uk-width-1-1">
          <h4>Participants by Type</h4>
          <div id="responsesParticipantsTypeWrapper" class="uk-panel uk-panel-box">
            <canvas id="responsesParticipantsType"></canvas>
          </div>
        </div>
      </div>
    </div>

    <?php include 'assets/footer.php' ?>
    <script src="assets/js/charts.min.js"></script>
    <script>
      
      $('.topbar.second > nav').append(
        '<div class="uk-navbar-flip">' +
          '<ul class="uk-navbar-nav">' +
            '<li>Filter by Location: <select name="group"><option value="0">Global</option><option value="manchester">Manchester</option><option value="mumbai">Mumbai</option></select></li>' +
            //'<li>Filter by World: <select name="challenge"><option value="0">-</option><option value="1">World 1</option><option value="2">World 2</option><option value="3">World 3</option></select></li>' +
          '</ul>' +
        '</div>'
      );   
      
      var groupFilter = $('.topbar.second > nav select[name="group"]');
      var challengeFilter = $('.topbar.second > nav select[name="challenge"]');
      var chartData1 = [];
      
      
      groupFilter.change(function() {
        challengeFilter.prop('selectedIndex', 0);
        var selected = $(this).val();
        if (selected != 0) {
          getGroupStats(selected);
        } else {
          getGlobalStats();
        }
      });
     
      getGlobalStats();

      function getGlobalStats() {
        sendRequest('getStats', 'global', user).done(function(data) {
          var labelData1 = [];
          var chartData1 = [];
          var labelData2 = [];
          var chartData2 = []; 
          var labelData4 = [];
          var chartData4 = [];
          var labelData5 = [];
          var chartData5 = [];
          var labelData6 = [];
          var chartData6 = [];
          
          $('#deadline').parent().hide();
          $('#voteList').hide();  
          $('#barChart').show();  
          $('#participantTotal').parent().show();
          $('#participantTotal h3').text(data[4]);
          $('#responseTotal h3').text(data[0]);
          $('#memberTotal').parent().show();
          $('#memberTotal h3').text(data[2]);
          
          labelData1 = dates(data[1][0][1]);

          $.each(labelData1, function(index2, value2) {
            var added = false;
            $.each(data[1], function(index1, value1) {
              if (value2 == value1[1]) {
                chartData1.push(value1[0]);
                added = true;
              }
            });
            if (!added) {
              chartData1.push(0);
            }
          });
          
          labelData4 = dates(data[5][0][1]);
          
          $.each(labelData4, function(index2, value2) {
            var added = false;
            $.each(data[5], function(index1, value1) {
              if (value2 == value1[1]) {
                chartData4.push(value1[0]);
                added = true;
              }
            });
            if (!added) {
              chartData4.push(0);
            }
          });
                   
          $.each(data[2], function( index, value ) {
            labelData2.push(value[0]);
          });
                          
          $.each(data[2], function( index, value ) {
            chartData2.push(value[1]);
          });
          
          $.each(data[6], function( index, value ) {
            labelData5.push(value[0]);
          });
                          
          $.each(data[6], function( index, value ) {
            chartData5.push(value[1]);
          });
                 
          var techArr = [];
          
          $.each(data[3], function(i,v) {
            var techObj = Object.keys(JSON.parse(v[0]));
            techArr = techArr.concat(techObj);
          });
          
          var counts = {};

          techArr.forEach(function(x) { counts[x] = (counts[x] || 0)+1; });
          
          var labelData3 = Object.keys(counts);
          var chartData3 = [];
                    
          for (var key in counts) {
              if (Object.prototype.hasOwnProperty.call(counts, key)) {
                  var val = counts[key];
                  chartData3.push(val);
              }
          }

          $.each(data[7], function(i,v) {
           labelData6.push(i);
           chartData6.push(v);
          });
          
          prepareCharts(labelData1, chartData1, labelData2, chartData2, labelData3, chartData3, labelData4, chartData4, labelData5, chartData5, labelData6, chartData6);
          
        }).fail(function(data) {
          console.log("Error");
          console.log(data);
        });
      }
      
      
      function parseDate(str) {
        var mdy = str.split('-');
        return new Date(mdy[2], mdy[1] - 1, mdy[0]);
      }

      function daydiff(first) {
        return Math.round((Date.now() - first) / (1000 * 60 * 60 * 24 * 7));
      }
      
      function getMonday(d) {
        d = new Date(d);
        var day = d.getDay(),
            diff = d.getDate() - day + (day == 0 ? -6:1) + 1; // adjust when day is sunday
        return new Date(d.setDate(diff));
      }
      
      function dates(date) {
        var weeks = new Array();
        var current = getMonday(new Date());
        current.setDate(current.getDate() - 1);
        for (var i = -1; i < daydiff(parseDate(date))+1; i++) {
          var before = current - 1000 * 60 * 60 * 24 * 7 * i;
          before = new Date(before);         
          weeks.push(('0' + before.getDate()).slice(-2) + '-' + ('0' + (before.getMonth()+1)).slice(-2) + '-2016');
        }
        return weeks.reverse();
      }      
      
      function getGroupStats(id){
        sendRequest('getStats', 'group, '+ id, user).done(function(data) {
          var labelData1 = [];
          var chartData1 = [];
          var labelData2 = [];
          var chartData2 = []; 
          var labelData4 = [];
          var chartData4 = [];
          var labelData5 = [];
          var chartData5 = [];
          var labelData6 = [];
          var chartData6 = [];
          
          $('#deadline').parent().hide();
          $('#voteList').hide();  
          $('#barChart').show();  
          $('#participantTotal').parent().show();
          $('#participantTotal h3').text(data[4]);
          $('#responseTotal h3').text(data[0]);
          $('#memberTotal').parent().show();
          $('#memberTotal h3').text(data[2]);
          
          if (data[1][0]) {
            labelData1 = dates(data[1][0][1]);
          }
          
          $.each(labelData1, function(index2, value2) {
            var added = false;
            $.each(data[1], function(index1, value1) {
              if (value2 == value1[1]) {
                chartData1.push(value1[0]);
                added = true;
              }
            });
            if (!added) {
              chartData1.push(0);
            }
          });
                    
          if (data[5][0]) {
            labelData4 = dates(data[5][0][1]);
          }

          $.each(labelData4, function(index2, value2) {
            var added = false;
            $.each(data[5], function(index1, value1) {
              if (value2 == value1[1]) {
                chartData4.push(value1[0]);
                added = true;
              }
            });
            if (!added) {
              chartData4.push(0);
            }
          });

          $.each(data[2], function( index, value ) {
            labelData2.push(value[0]);
          });

          $.each(data[2], function( index, value ) {           
            chartData2.push(value[1]);            
          });
          
          $.each(data[6], function( index, value ) {
            labelData5.push(value[0]);
          });
                          
          $.each(data[6], function( index, value ) {
            chartData5.push(value[1]);
          });
          
          var techArr = [];
          
          $.each(data[3], function(i,v) {
            var techObj = Object.keys(JSON.parse(v[0]));
            techArr = techArr.concat(techObj);
          });
          
          var counts = {};

          techArr.forEach(function(x) { counts[x] = (counts[x] || 0)+1; });
          
          var labelData3 = Object.keys(counts);
          var chartData3 = [];
                    
          for (var key in counts) {
              if (Object.prototype.hasOwnProperty.call(counts, key)) {
                  var val = counts[key];
                  chartData3.push(val);
              }
          }
          
          $.each(data[7], function(i,v) {
           labelData6.push(i);
           chartData6.push(v);
          });
                    
          prepareCharts(labelData1, chartData1, labelData2, chartData2, labelData3, chartData3, labelData4, chartData4, labelData5, chartData5, labelData6, chartData6);
          
        }).fail(function(data) {
          console.log("Error");
          console.log(data);
        });
      }
      
      function sendRequest(cmd, data, user) {
        data = {
          'cmd': cmd,
          'data': data,
          'user': user,
        }

        return $.ajax({
          method: "POST",
          url: "../api.php",
          dataType: "json",
          data: data
        });
      }
      
      
      // --------- CHARTS ------------ //
      
      Chart.defaults.global.responsive = true;

      function prepareCharts(labels1, chartData1, labels2, chartData2, labels3, chartData3, labels4, chartData4, labels5, chartData5, labels6, chartData6) {

        var data1 = {
          type: 'line',
          data: {
            labels: labels1,
            datasets: [{
              label: "Responses over time",
              backgroundColor: "rgba(35,44,59,0.5)",
              borderColor: "rgba(35,44,59,1)",
              borderWidth: "2",
              data: chartData1
            }]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  mirror: false,
                  suggestedMin: 0,
                }
              }]
            }
          }
        };
        
        var data2 = {
          type: 'bar',
          data: {
            labels: ['World 1', 'World 2', 'World 3'],
            datasets: [{
              label: "Responses by statement",
              backgroundColor: "rgba(35,44,59,0.5)",
              borderColor: "rgba(35,44,59,1)",
              borderWidth: "2",
              data: chartData2
            }]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  mirror: false,
                  suggestedMin: 0,
                }
              }]
            }
          }
        };
        
        var data3 = {
          type: 'bar',
          data: {
            labels: labels3,
            datasets: [{
              label: "Prefered Technologies",
              backgroundColor: "rgba(35,44,59,0.5)",
              borderColor: "rgba(35,44,59,1)",
              borderWidth: "2",
              data: chartData3
            }]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  mirror: false,
                  suggestedMin: 0,
                }
              }]
            }
          }
        };
        
        var data4 = {
          type: 'line',
          data: {
            labels: labels4,
            datasets: [{
              label: "Participants over time",
              backgroundColor: "rgba(35,44,59,0.5)",
              borderColor: "rgba(35,44,59,1)",
              borderWidth: "2",
              data: chartData4
            }]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  mirror: false,
                  suggestedMin: 0,
                }
              }]
            }
          }
        };
        
        var data5 = {
          type: 'bar',
          data: {
            labels: labels5,
            datasets: [{
              label: "Responses by statement",
              backgroundColor: "rgba(35,44,59,0.5)",
              borderColor: "rgba(35,44,59,1)",
              borderWidth: "2",
              data: chartData5
            }]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  mirror: false,
                  suggestedMin: 0,
                }
              }]
            }
          }
        };
        
        var data6 = {
          type: 'bar',
          data: {
            labels: labels6,
            datasets: [{
              label: "Participants by Type",
              backgroundColor: "rgba(35,44,59,0.5)",
              borderColor: "rgba(35,44,59,1)",
              borderWidth: "2",
              data: chartData6
            }]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true,
                  mirror: false,
                  suggestedMin: 0,
                }
              }]
            }
          }
        };
        
        $('#responsesTime').remove();
        $('#responsesTimeWrapper').append('<canvas id="responsesTime"><canvas>');
        $('#responsesChallenge').remove();
        $('#responsesChallengeWrapper').append('<canvas id="responsesChallenge"><canvas>');
        $('#responsesTech').remove();
        $('#responsesTechWrapper').append('<canvas id="responsesTech"><canvas>');
        $('#responsesParticipantsTime').remove();
        $('#responsesParticipantsTimeWrapper').append('<canvas id="responsesParticipantsTime"><canvas>');
        $('#responsesMarketing').remove();
        $('#responsesMarketingWrapper').append('<canvas id="responsesMarketing"><canvas>');
        $('#responsesParticipantsType').remove();
        $('#responsesParticipantsTypeWrapper').append('<canvas id="responsesParticipantsType"><canvas>');

        var line = $("#responsesTime");
        var reponsesTime = new Chart(line, data1);

        var bar = $("#responsesChallenge");
        var responsesChallenge = new Chart(bar, data2);
        
        var bar2 = $("#responsesTech");
        var responsesTech = new Chart(bar2, data3);
        
        var line2 = $("#responsesParticipantsTime");
        var reponsesParticipantsTime = new Chart(line2, data4);
        
        var bar3 = $("#responsesMarketing");
        var responsesMarketing = new Chart(bar3, data5);
        
        var bar4 = $("#responsesParticipantsType");
        var responsesParticipantsType = new Chart(bar4, data6);
      }
      
    </script>
  </body>
</html>