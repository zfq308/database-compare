<?php require_once'assets/session.php' ?>

<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Rise Hackathon | Admin - Responses</title>
  <meta name="description" content="Rise Hackathon">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/8.5.1/nouislider.min.css" />
  <?php include 'assets/header.php' ?>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.26.4/css/components/tooltip.almost-flat.min.css" />
</head>

<body>
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
  
  <?php include 'assets/topbar.php' ?>

  <div class="uk-container white uk-margin-large-top">
    <div class="uk-grid">
      <div class="uk-width-2-10">
        <img id="companyLogo" src="assets/img/placeholder.svg">
        <div class="score-total"></div>
      </div>
      <div class="uk-width-8-10">
        <div class="uk-grid response-details">
          <div id="teamInfo" class="uk-width-1-1">
            <h2>Team name: <span id="name"></span></h2><?php if (($_SESSION["user_group"] == 1)): ?><span><a class="uk-button uk-button-primary" href="#change-stage" data-uk-modal>Change Stage</a></span><?php endif; ?><span id="website"></span><span id="docs"></span>
            <div><span id="location"></span> - <span id="statement"></span> - <span id="stage"></span></div>
          </div>   
          <div id="idea" class="uk-width-1-1">
            <h3>Describe your idea</h3>
            <p></p>
          </div>
          <br>
          <div id="benefit" class="uk-width-1-1">
            <h3>What makes your idea and team standout from the competition?</h3>
            <p></p>
          </div>
        </div>
      </div>  
      <div class="uk-width-1-1 team-members">
        <h4>Team Members</h4>

          <table class="uk-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>E-Mail</th>
                <th>Phone</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Position</th>
              </tr>
            </thead>
            <tbody class="list">

            </tbody>
          </table>

      </div>
    </div>
    <?php if (($_SESSION["user_group"] == 1) || ($_SESSION["user_group"] == 4) || ($_SESSION["user_group"] == 5)): ?>
    <div id="score">
      <h4>Score</h4>
      <div class="uk-grid">
        <div class="score-title uk-width-2-10">
          <span data-uk-tooltip title="Creating a world-class project, or world-changing one, requires the ability to get others on board.">Demo</span>
        </div>
        <div id="score-slider-1" class="uk-width-7-10"></div>
        <div id="score-value-1" class="score-value uk-width-1-10"></div>
      </div>
      <div class="uk-grid">
        <div class="score-title uk-width-2-10">
          <span data-uk-tooltip title="How successfully have you solved the challenge set by Barclays in each world and have you used Barclays APIs where possible?">Application to Barclays</span></div>
        <div id="score-slider-2" class="uk-width-7-10"></div>
        <div id="score-value-2" class="score-value uk-width-1-10"></div>
      </div>
      <div class="uk-grid">
        <div class="score-title uk-width-2-10">
          <span data-uk-tooltip title="Does the product have the ability to disrupt current markets and capture large market share?">Product Vision</span></div>
        <div id="score-slider-3" class="uk-width-7-10"></div>
        <div id="score-value-3" class="score-value uk-width-1-10"></div>
      </div>
      <div class="uk-grid">
        <div class="score-title uk-width-2-10">
          <span data-uk-tooltip title="How successfully have you integrated Barclays APIs and/or partner APIs?">API Implementation</span></div>
        <div id="score-slider-4" class="uk-width-7-10"></div>
        <div id="score-value-4" class="score-value uk-width-1-10"></div>
      </div>
      <div class="uk-grid">
        <div class="score-title uk-width-2-10">
          <span data-uk-tooltip title="Does the product have exceptional design attributes that would appeal to the end-user?">Product Design</span></div>
        <div id="score-slider-5" class="uk-width-7-10"></div>
        <div id="score-value-5" class="score-value uk-width-1-10"></div>
      </div>
      <div class="uk-grid">
        <div class="score-title uk-width-2-10">
          <span data-uk-tooltip title="Evaluate the technical achievement the team has tackled during the event.">Technical Achievement</span></div>
        <div id="score-slider-6" class="uk-width-7-10"></div>
        <div id="score-value-6" class="score-value uk-width-1-10"></div>
      </div>
      <div class="submit-score uk-clearfix">
        <span class="score-avg"></span> <a class="uk-button uk-button-primary uk-float-right" href="#">Submit Score</a>
      </div>
    </div>
    <?php endif; ?>
    
    <?php if (($_SESSION["user_group"] == 1)): ?>
      <div class="uk-width-1-1 scores">
        <h4>Scores</h4>
          <table class="uk-table">
            <thead>
              <tr>
                <th>Judge</th>
                <th>Scores</th>
                <th>Average</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody class="list">

            </tbody>
          </table>
      </div>
    <?php endif; ?>
    
    <?php if (($_SESSION["user_group"] == 1) || ($_SESSION["user_group"] == 4) || ($_SESSION["user_group"] == 5)): ?>
    <div id="notes" class="note-list">
      <h4>Comments</h4>
      <div class="uk-form">
        <div class="uk-form-row">
          <textarea id="newNote" rows="8" placeholder="Enter your note here" class="uk-width-1-1"></textarea>
          <button id="addNote" class="uk-button uk-button-primary uk-button-large">Add Comment</button>
        </div>
      </div>
      <div id="noteList" class="uk-margin-large-top"></div>
    </div>
    <?php endif; ?>
    <?php if (($_SESSION["user_group"] == 1)): ?>
    <div id="video">
      <h4>Video</h4>
      <form id="videoForm" class="uk-form">
        <div class="uk-form-row">
          <label class="uk-form-label" for="video-link">Link</label>
          <textarea id="video-link" rows="4" class="uk-width-1-1" name="link"></textarea>
        </div>
        <div class="uk-form-row">
          <label class="uk-form-label" for="video-summary">Summary</label>
          <input id="video-summary" type="text" class="uk-width-1-1" name="summary">
        </div>
<!--         <div class="uk-form-row">
          <label class="uk-form-label" for="video-description">Description</label>
          <textarea id="video-description" rows="4" class="uk-width-1-1" name="description"></textarea>
        </div> -->
<!--         <div class="uk-form-row">
          <label class="uk-form-label" for="video-comments">Judge Comments</label>
          <textarea id="video-comments" rows="4" class="uk-width-1-1" name="comments"></textarea>
        </div> -->
<!--         <div class="uk-form-row">
          <label class="uk-form-label" for="video-technologies">Technologies used</label>
          <input id="video-technologies" type="text" class="uk-width-1-1" name="technologies">
        </div> -->
        <div class="uk-form-row">
          <label class="uk-form-label" for="video-tags">Tags</label>
          <input id="video-tags" type="text" class="uk-width-1-1" name="tags">
        </div>
        <div class="uk-form-row">
          <label class="uk-form-label" for="video-position">Position</label>
          <select id="video-position" class="uk-width-1-1" name="position">
            <option value="0">-</option>
            <option value="1">Winner</option>
            <option value="2">Runner Up</option>
          </select>
        </div>
      </form>
      <div class="submit-video uk-clearfix">
        <a class="uk-button uk-button-primary uk-float-right" href="#">Add Video</a>
      </div>
    </div>
    <?php endif; ?>
  </div>
  
  <div id="no-docs" class="uk-modal">
    <div class="uk-modal-dialog">
      <a class="uk-modal-close uk-close"></a>
      <div class="uk-modal-header"><h1>No Documents</h1></div>
      Applicant did not provide any documents/files.
    </div>
  </div>
  
  <div id="no-link" class="uk-modal">
    <div class="uk-modal-dialog">
      <a class="uk-modal-close uk-close"></a>
      <div class="uk-modal-header"><h1>No Link</h1></div>
      Applicant did not provide link to demonstration.
    </div>
  </div>
  
  <div id="external-link" class="uk-modal">
    <div class="uk-modal-dialog">
      <a class="uk-modal-close uk-close"></a>
      <div class="uk-modal-header"><h1>External Link</h1></div>
      Following URL was provided by applicant as demonstration of their solution.
      <p class="uk-text-large"></p>
      Clicking on Continue button will open provided link in the new window.
      <div class="uk-modal-footer uk-text-right">
        <a class="uk-button uk-modal-close">Cancel</a>
        <a id="externalContinue" class="uk-button uk-button-primary" href="#" target="_blank">Continue</a>
      </div>
    </div>
  </div>
  
  <div id="change-stage" class="uk-modal">
    <div class="uk-modal-dialog">
      <a class="uk-modal-close uk-close"></a>
      <div class="uk-modal-header"><h1>Change Stage</h1></div>
      <p>Please select stage from the list below.</p>
      <select id="changeSelect">
        <option value="1">Stage I</option>
        <option value="2">Stage II</option>
        <option value="3">Semi-Finals</option>
        <option value="4">Final</option>
      </select>
      <div class="uk-modal-footer uk-text-right">
        <a class="uk-button uk-modal-close">Cancel</a>
        <buton id="changeStageBtn" class="uk-button uk-button-primary">Change</button>
      </div>
    </div>
  </div>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/8.5.1/nouislider.min.js"></script>
  <?php include 'assets/footer.php' ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.26.4/js/components/tooltip.min.js"></script>
  
  <script>
    function getUrlParameter(sParam) {
      var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

      for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
          return sParameterName[1] === undefined ? true : sParameterName[1];
        }
      }
    }
    
    var view = getUrlParameter('view');
    var id = getUrlParameter('response');

    getResponse();
    getNotes();
    getScore();
    getVideo();
    getScores();

    if (view == 'notes') {
      $('html,body').animate({scrollTop: $('#notes').offset().top},'slow');
    }

    function getResponse() {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "getResponse",
          data: id,
          user: user
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {

          var response = data.data[0];
          
          if (response.logo != '') {
            $("#companyLogo").attr('src', '../upload/' + response.id + '/' + response.logo);
          }

          $('#name').text(response.name);

          var link = response.url;
          
          if (link != '') {

            if (link.toLowerCase().indexOf("http://") <= 0) {
              link = 'http://' + link
            }
            
            link = '<a id="demoLink" class="uk-button uk-button-success" href="#external-link" data-uk-modal data-link="'+link+'">Demo</a>';
            
          } else {
            link = '<a id="demoLink" class="uk-button" href="#no-link" data-uk-modal>Demo</a>';
          }
          
          var docs = response.docs;

          if (docs != '') {
            docs = '<a id="docsLink" class="uk-button uk-button-success" href="../upload/' + response.id + '/" target="_blank">Documents</a>';
          } else {
            docs = '<a id="docsLink" class="uk-button" href="#no-docs" data-uk-modal>Documents</a>';
          }

          $('#website').html(link);
          $('#docs').html(docs);
          $('#location').html(response.location);
          $('#statement').html(response.statement);
          $('#idea p').html(response.idea);
          $('#benefit p').html(response.benefit);

          $('.team-members .list').empty();
          
          $.each(jQuery.parseJSON(response.members), function( index, member ) {
            $('.team-members .list').append(
              '<tr>' +
                '<td>' + member.name + '</td>' +
                '<td>' + member.email + '</td>' +
                '<td>' + member.number + '</td>' +
                '<td>' + member.age + '</td>' +
                '<td>' + member.gender + '</td>' +
                '<td>' + member.position + '</td>' +
              '</tr>'
            );        
          });

          $('.score-total').html(Math.round(response.score * 100) / 100 + '<p>Average<br>Score</p>');
          
          switch (parseInt(response.stage)) {
            case 1:
              $('#stage').html('Stage ' + response.stage);
              break;
            case 2:
              $('#stage').html('Stage ' + response.stage);
              break;
            case 3:  
              $('#stage').html('Semi-Final');
              $('.score-total').show();
              $('#score').show();
              $('#video').show();            
              if (response.zero_check == '1') {
                $('.score-total').addClass('average-score-red');
              } else {
                $('.score-total').removeClass('average-score-red');
              }
              break;
            case 4:
              $('#stage').html('Final');
              $('.score-total').show();
              $('#score').show();
              $('#video').show();
              if (response.zero_check == '1') {
                $('.score-total').addClass('average-score-red');
              } else {
                $('.score-total').removeClass('average-score-red');
              }
              break;
            default:
          }        
        }
      });
    }

    $('#addNote').on('click', function() {
      var data = [];
      data.push($('#newNote').val());
      data.push(id);
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "addNote",
          user: user,
          data: data
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          UIkit.notify(data.data, {
            status: 'success'
          });
          getNotes();
        }
      });
    });

    function getNotes() {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "getNotes",
          user: user,
          data: id
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          $('#noteList').empty();
          $.each(data.data, function(index, value) { 
            $('#noteList').append(
              '<div class="note">' +
                '<p class="note-content">' + value.note_content + '</p>' +
                '<span class="uk-text-muted"><b>' + value.user_name + '</b> ' + value.note_created + '</span>' +
              '</div>'
            );
          });
        }
      });
    }  
    
    // Score Sliders  
    var options = { 
        start: [5],
        step: 1,
        connect: 'lower',
        range: {
          'min': [0],
          'max': [10]
        }
    };
    
    <?php if (($_SESSION["user_group"] == 1) || ($_SESSION["user_group"] == 4) || ($_SESSION["user_group"] == 5)): ?>
    
    for (var i = 1; i < 7; i++) {
      var a = i; //Safari fix (var instead of let)
      var scoreSlider = document.getElementById('score-slider-' + a);

      noUiSlider.create(scoreSlider, {
        start: [5],
        step: 0.1,
        connect: 'lower',
        range: {
          'min': [0],
          'max': [10]
        },
        format: {
          to: function(value) {
            return value
          },
          from: function(value) {
            return value
          }
        }
      });
      
      scoreSlider.noUiSlider.on('update', function(values, handle) {
        $(this.target).siblings('.score-value').text(values[handle]);
        var average = scoreAverage();
        //console.log(average[1]);
        $('.score-avg').text('Your average score: ' + Math.round(average[1] * 100) / 100);
      });
   
    }

    <?php endif; ?>
    
    function scoreAverage() {
      var score = [];
      var total = 0;
      var average = 0;
      $('.score-value').each(function( index ) {
        var value = $(this).text();
        score.push(value);
        total += parseFloat(value);
      });
      average = total/score.length;
      //average = average.toString();
      score = JSON.stringify(score);
      var response = [];
      response.push(score);
      response.push(average);
      return response;
    }
    
    $('.submit-score a').on('click', function(e) {
      e.preventDefault();
      var average = scoreAverage();

      saveScore(average[0], average[1]);
      $(this).blur();
    });
    
    function saveScore(score, average) {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "saveScore",
          user: user,
          data: id + ", " + score + ", " + average
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          UIkit.notify(data.data, {
            status: data.status
          });
          getResponse();
          getScore();
        }
      });
    }
    
    function getScore() {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "getScore",
          user: user,
          data: id
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          if (data.data != '0') {
            var slider = "";
            $.each(data.data, function(index, value) { 
              slider = document.getElementById('score-slider-' + (index+1));
              slider.noUiSlider.set(value);
            });          
          }
        }
      });
    }
    
    function getScores() {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "getScores",
          user: user,
          data: id
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          data = data.data;
          console.log(data);
          $('.scores .list').empty();
                   
          $.each(data, function( index, score ) {
            
            if (score.zero_check == '1') {
              score.zero_check = 'red';
            }
            
            $('.scores .list').append(
              '<tr class="'+score.zero_check+'">' +
                '<td>' + score.user_name + '</td>' +
                '<td>' + JSON.parse(score.score).join(", ") + '</td>' +
                '<td>' + score.average + '</td>' +
                '<td>' + score.timestamp + '</td>' +
              '</tr>'
            );        
          });
        }
      });
    }

    $(document).on('click', '#demoLink', fn_buttonmodal_habndler);

    function fn_buttonmodal_habndler(e) {
      //get id from pressed button
      var fn_link = $(e.target).data('link');

      $('#external-link').on({
        'uk.modal.show': function() {
          $('p', $(this)).html(fn_link);
          $('#externalContinue', $(this)).attr('href', fn_link);
        },
        'uk.modal.hide': function() {
          //hide modal
        }
      }).trigger('uk.modal.show');
    }
    
    $('#changeStageBtn').on('click', function(e) {
      pushResponse($('#changeSelect').val(),id,'single');
    });
    
    $('.submit-video a').on('click', function(e) {
      e.preventDefault();
      saveVideo($('#videoForm').serialize());
    });
    
    function getVideo() {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "getVideo",
          user: user,
          data: id
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          if (data.data) {
            $.each(data.data, function(i,val) { $('#videoForm [name=\'' + i + '\']').val(val); });
          }
        }
      });
    }
    
    function saveVideo(data) {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "saveVideo",
          user: user,
          data: id + ", " + data
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          UIkit.notify(data.data, {
            status: data.status
          });
          getResponse();
        }
      });
    }
  </script>

</body>

</html>