<!doctype html>
<html class="uk-height-1-1 no-js" lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Rise Challenges | Admin - Add New Challenge</title>
  <meta name="description" content="Rise Challenges">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include 'assets/header.php' ?>
</head>

<body class="uk-height-1-1">
  <div class="uk-vertical-align uk-height-1-1">
    <div class="uk-vertical-align-middle uk-width-1-1 uk-text-center">
      <div style="max-width:384px; margin: 0 auto 2em;">
        <svg class="site-navigation__logo" height="98px" version="1.1" viewBox="0 0 66 43" width="150px" x="0px" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" y="0px">
          <g class="rise-logo-el dark">
          <path class="rise-logo" d="M14.1,22v-6.3c-0.5-0.1-0.9-0.1-1.5-0.1c-2,0-5.2,0.6-6.6,3.6v-3.4H0V39h6.2V28.4c0-5,2.8-6.5,6-6.5
                C12.8,21.8,13.4,21.9,14.1,22z"></path>
          <path class="rise-logo" d="M19,12c2.2,0,3.9-1.7,3.9-3.8c0-2.2-1.7-3.9-3.9-3.9c-2.1,0-3.9,1.7-3.9,3.9C15.1,10.3,16.9,12,19,12z"></path>
          <rect class="rise-logo" height="23.2" width="6.2" x="15.9" y="15.8"></rect>
          <path class="rise-logo" d="M42.5,32c0-3.4-2.3-6.2-6.8-7.1l-3.3-0.7c-1.3-0.2-2.1-0.9-2.1-2.1c0-1.3,1.3-2.3,3-2.3
                c2.6,0,3.6,1.7,3.8,3.1l5.2-1.2c-0.3-2.5-2.5-6.7-9-6.7c-5,0-8.6,3.4-8.6,7.6c0,3.3,2,5.9,6.5,6.9l3.1,0.7
                c1.8,0.4,2.5,1.2,2.5,2.3c0,1.2-1,2.3-3.1,2.3c-2.7,0-4.1-1.7-4.2-3.5L24,32.5c0.3,2.6,2.7,7.2,9.6,7.2
                C39.6,39.7,42.5,35.8,42.5,32z"></path>
          <path class="rise-logo" d="M50.4,38.5l4.3-4.3c-2.6-0.4-4.7-2.5-4.8-5.2h10l6.1-6.1c-1.4-4.9-5.2-7.8-10.9-7.8
                c-5.9,0-11.3,4.8-11.3,12.2C43.8,32.8,46.5,36.7,50.4,38.5z M55.2,20.2c3.6,0,5.1,2.3,5.2,4.6H50.1C50.2,22.6,52,20.2,55.2,20.2z"></path>
          </g>
        </svg>
      </div>
      <?php include "assets/login.php" ?>
    </div>
  </div>
</body>

</html>