<?php require_once'assets/session.php' ?>

<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Rise Challenges | Admin</title>
  <meta name="description" content="Rise Challenges">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="assets/css/form-builder.min.css">
  <link rel="stylesheet" href="assets/codemirror/lib/codemirror.css">
  <link rel="stylesheet" type="text/css" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.css">
  <?php include 'assets/header.php' ?>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/components/datepicker.almost-flat.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/components/form-select.almost-flat.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/components/upload.almost-flat.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/components/placeholder.almost-flat.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/components/progress.almost-flat.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/components/form-file.almost-flat.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/components/htmleditor.almost-flat.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/components/sortable.almost-flat.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.26.2/css/components/tooltip.almost-flat.min.css">

  <!-- Codemirror and marked dependencies -->
  <script src="assets/codemirror/lib/codemirror.js"></script>
  <script src="assets/codemirror/mode/markdown/markdown.js"></script>
  <script src="assets/codemirror/addon/mode/overlay.js"></script>
  <script src="assets/codemirror/mode/xml/xml.js"></script>
  <script src="assets/codemirror/mode/gfm/gfm.js"></script>
  <script src="assets/js/marked.min.js"></script>
</head>

<body>
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

  <?php include 'assets/topbar.php' ?>
  <div class="uk-container white challenge-manage uk-margin-large-top">
    <h1 class="uk-margin-top uk-text-center"></h1>

    <h2>Basic Info</h2>
    <form id="addChallengeForm" class="uk-form uk-form-stacked">
      <fieldset>
        <div class="uk-form-row">
          <div class="uk-grid">
            <div class="uk-width-1-2">
              <label class="uk-form-label" for="">Title</label>
              <input id="title" type="text" placeholder="Title" class="uk-width-1-1">
            </div>
            <div class="uk-width-1-2">
              <label class="uk-form-label" for="">Deadline</label>
              <input id="deadline" type="text" placeholder="DD.MM.YYYY" data-uk-datepicker="{format:'DD.MM.YYYY'}" class="uk-width-1-1">
            </div>
          </div>
        </div>
        <div class="uk-form-row">
          <div class="uk-width-1-1">
            <label class="uk-form-label" for="">Description</label>
            <textarea id="description" type="text" placeholder="Description" rows="8" class="uk-width-1-1"></textarea>
          </div>
        </div>
        <div class="uk-form-row">
          <div class="uk-width-1-1">
            <label class="uk-form-label" for="">Details</label>
            <textarea id="details" type="text" placeholder="Details" rows="8" class="uk-width-1-1"></textarea>
          </div>
        </div>
        <div class="uk-form-row">
          <div class="uk-width-1-1">
            <label class="uk-form-label" for="">Reward (What’s in it for me?)</label>
            <textarea id="reward" type="text" placeholder="What’s in it for me?" rows="8" class="uk-width-1-1"></textarea>
          </div>
        </div>
        <div class="uk-form-row">
          <div class="uk-width-1-1">
            <label class="uk-form-label" for="">Judging Criteria</label>
            <textarea id="criteria" type="text" placeholder="Judging Criteria" rows="8" class="uk-width-1-1"></textarea>
          </div>
        </div>

        <div class="uk-form-row uk-text-center">
          <label class="uk-form-label" for="">Challenge Image</label>
          <div id="upload-drop" class="uk-placeholder uk-text-center">
            <i class="uk-icon-cloud-upload uk-icon-medium uk-text-muted uk-margin-small-right"></i> Add an image by dragging one here or <a class="uk-form-file">selecting a file<input id="upload-select" type="file"></a>.
          </div>
          <div id="progressbar1" class="uk-progress uk-hidden">
            <div class="uk-progress-bar" style="width: 0%;"></div>
          </div>
        </div>
        <div class="uk-form-row uk-text-center">
          <div id="uploadMessage1"></div>
          <div class="uk-thumbnail">
            <img id="upload-image-preview" src="assets/img/placeholder.svg" alt="Image Preview">
            <div class="uk-thumbnail-caption">Main Challenge Image Preview</div>
          </div>
        </div>
      </fieldset>
    </form>

    <h2>Slider</h2>

    <div class="uk-grid">
      <div class="uk-width-1-1">

        <div id="progressbar2" class="uk-progress uk-hidden">
          <div class="uk-progress-bar" style="width: 0%;"></div>
        </div>
        <div class="uk-text-center">
          <div id="uploadMessage2"></div>
        </div>

        <ul id="slider-list" class="uk-sortable uk-grid uk-grid-small uk-grid-width-1-4 uk-margin" data-uk-sortable></ul>
        <div class="uk-form-file uk-hidden">
          <input id="slider-upload" type="file">
        </div>
        <button id="slider-upload-button" class="uk-button uk-button-primary uk-button-large">Upload Image/Video</button>
        <button id="slider-embed-button" class="uk-button uk-button-primary uk-button-large" type="button" onclick="sliderModal()">Embed Video</button>
      </div>
    </div>

    <h2>Tags</h2>

    <div class="uk-grid">
      <div class="uk-width-1-2">
        <h3>Available Tags</h3>
        <div class="uk-panel uk-panel-box">
          <ul id="availableTags" class="uk-sortable" data-uk-sortable="{group:'my-group'}"></ul>
        </div>
      </div>

      <div class="uk-width-1-2">
        <h3>Selected Tags</h3>
        <div class="uk-panel uk-panel-box green">
          <ul id="selectedTags" class="uk-placeholder uk-sortable" data-uk-sortable="{group:'my-group'}"></ul>
        </div>
      </div>
    </div>

    <h2>Response Form</h2>
    <textarea name="form-builder" id="form-builder" cols="30" rows="10"></textarea>

    <h3>After Submission Information</h3>
    <textarea id="additional" type="text" placeholder="After Submission Information" rows="8" class="uk-width-1-1"></textarea>

    <div class="uk-text-center">
      <div id="submitMessage" class="uk-margin-top"></div>
      <a id="submitChallenge" href="#" class="uk-button uk-button-primary uk-button-large uk-margin-large-bottom">Add Challenge</a>
    </div>
  </div>

  <?php include 'assets/footer.php' ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  <script src="assets/js/form-builder.min.js"></script>
  <script src="assets/js/form-render.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/js/components/datepicker.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/js/components/upload.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/js/components/htmleditor.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/js/components/sortable.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/js/components/tooltip.min.js"></script>
  <script>
    var cmd;
    var title;
    var type = getUrlParameter('action');
    var challengeId = getUrlParameter('id');
    var challengeData;
    var tempDir = randomTempId();

    $(document).ready(function() {
      formData = '<form-template><fields><field class="form-control" label="Company Name" name="company-name" placeholder="Company &amp; Co LTD" required="true" type="text" subtype="text"></field><field class="form-control text-area" label="Company Description" maxlength="140" name="company-description" placeholder="e.g. “we are experts in developing fun loyalty mechanics on mobile" required="true" type="textarea"></field><field class="form-control file-input" label="Company Logo" name="company-logo" required="true" type="file"></field><field class="form-control text-input" label="Contact Name" name="contact-name" required="true" type="text" subtype="text"></field><field class="form-control text-input" label="Contact Email" name="contact-email" placeholder="email@example.com" required="true" type="text" subtype="email"></field><field class="form-control" label="Company Website" name="company-website" placeholder="http://www.example.com/" required="true" type="text" subtype="text"></field><field class="form-control text-area" label="What makes your company stand out from the competition?" maxlength="500" name="company-stand-out" required="true" type="textarea" subtype="textarea"></field><field class="form-control select" label="Have you received investment?" name="company-investment" required="true" type="select"><option value="Yes">Yes</option><option value="No">No</option></field><field class="form-control text-input" label="Funds raised to date" name="funds-raised" placeholder="&amp;pound;2000" type="text" subtype="text"></field><field class="form-control calendar" label="Date Founded" name="founded" required="true" type="date" placeholder="yyyy-mm-dd"></field><field class="form-control text-input" label="Size of team" name="team-size" required="true" type="text" subtype="text"></field></fields></form-template>',
        formRenderOpts = {
          render: false,
          formData: formData
        };

      initializeAssets(tempDir);
      
      if (type == 'new') {
        
        cmd = 'addChallenge';
        title = 'New Challenge';
        $('.challenge-manage > h1').text(title);
        document.title = document.title + " - " + title;
        var htmleditor1 = UIkit.htmleditor($('#details'));
        var htmleditor2 = UIkit.htmleditor($('#description'));
        var htmleditor3 = UIkit.htmleditor($('#criteria'));
        var htmleditor4 = UIkit.htmleditor($('#additional'));
        var htmleditor5 = UIkit.htmleditor($('#reward'));
        
      } else if (type = 'update') {
        
        cmd = 'updateChallenge';
        title = 'Edit Challenge';
        $('.challenge-manage > h1').text(title);
        document.title = document.title + " - " + title;
        $('#submitChallenge').text('Save Challenge');

        manageChallenge('getChallenges', challengeId).done(function(result) {
          if ($.isArray(result.data)) {
            populateInputs(result.data);
          }
        }).fail(function() {
          console.log("Error");
          console.log(data);
        });

      } else {

      }
    });

    function initializeAssets(tempDir) {
      var template = document.getElementById('form-builder'),
        options = {
          prepend: new FormRenderFn(formRenderOpts).markup
        };
      $(template).formBuilder(options);
      getTags();
      initializeFileUploadUI(JSON.parse('{"tempDir":"' + tempDir + '"}'));
    }


    $('#submitChallenge').on('click', function(e) {
      e.preventDefault();

      var data = validateChallengeData();

      if (type == 'update') {
        data.push(challengeId);
      }

      if (data[0]) {

        data.shift();
        data = JSON.stringify(data);
        submitChallenge(cmd, data, user, tempDir);
      }
    });

    $('#slider-upload-button').on('click', function(e) {
      e.preventDefault();
      $('#slider-upload').trigger('click');
    });
    
    $('#slider-list').on('click', '.slider-remove-button', function(e) {
      e.preventDefault();
      $(this).parents('li').remove();
    });
  </script>
</body>

</html>