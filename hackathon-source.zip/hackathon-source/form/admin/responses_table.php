<?php require_once'assets/session.php' ?>

<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Rise Hackathon | Admin - Responses</title>
  <meta name="description" content="Rise Hackathon">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include 'assets/header.php' ?>
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->

  <?php include 'assets/topbar.php' ?>
  <div class="uk-container white uk-margin-large-top">
    
    <?php if (($_SESSION["user_group"] == 1)): ?>
    <div class="uk-text-center">
      <button id="mumbaiData" class="uk-button uk-button-primary export-button">Export Mumbai Data</button>
      <button id="manchesterData" class="uk-button uk-button-primary export-button">Export Manchester Data</button>    
    </div>
    
    <br><br>
    <?php endif; ?>
    
    <table id="example" class="uk-table uk-table-hover uk-table-striped" cellspacing="0" width="100%"></table>
  </div>

  <?php include 'assets/footer.php' ?>
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

  <script>
    var mumbaiData,
        manchesterData;
    
    $(document).ready(function() {
      getResponses('all');
    });

    function getResponses(id) {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "getResponses",
          data: id + ',' + 'stage',
          user: user
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
//           data = data.data;
//           console.log(data);
//           data = $.parseJSON(data);
          
          console.log(data.data);
          
          mumbaiData = $.grep(data.data, function( n, i ) {
            return n.location==='Mumbai' && n.stage==="2";
          });
          
          manchesterData = $.grep(data.data, function( n, i ) {
            return n.location==='Manchester' && n.stage==="2";
          });
          
          $('#example').DataTable({
            data: data.data,
            info: false,
            columns: [{
              title: 'ID',
              data: 'id'
            }, {
              title: 'Location',
              data: 'location'
            }, {
              title: 'Statement',
              data: 'statement'
            }, {
              title: 'Team Name',
              data: 'name'
            }, {
              title: 'Team Logo',
              data: 'logo',
              "fnCreatedCell": function(nTd, sData, oData, iRow, iCol) {
                $(nTd).html("<a href='upload/" + oData.id + "/" + oData.logo + "' target='_blank'>" + oData.logo + "</a>");
              },
              visible: false,
              searchable: false
            }, {
              title: 'Team Members',
              data: 'members',
              "fnCreatedCell": function(nTd, sData, oData, iRow, iCol) {
                $(nTd).empty();
                $.each(sData, function(key, value) {
                  $(nTd).append(value.name + "<br>");
                });
              },
              visible: false,
              searchable: false
            }, {
              title: 'Primary Phone Number',
              data: 'phone'
            }, {
              title: 'Idea Description',
              data: 'idea',
              visible: false,
              searchable: false
            }, {
              title: 'Demo URL',
              data: 'url',
              visible: false,
              searchable: false
            }, {
              title: 'Standout',
              data: 'benefit',
              visible: false,
              searchable: false
            }, {
              title: 'Supporting Documents',
              data: 'docs',
              "fnCreatedCell": function(nTd, sData, oData, iRow, iCol) {
                $(nTd).empty();
                if (sData) {
                  $.each(sData, function(key, value) {
                    $(nTd).append("<a href='upload/" + oData.id + "/" + value + "' target='_blank'>File " + (key + 1) + "</a><br>");
                  });
                }
              },
              visible: false,
              searchable: false
            }, {
              title: 'Source',
              data: 'source',
              visible: false,
              searchable: false
            }, {
              title: 'Source - Other',
              data: 'source_other',
              visible: false,
              searchable: false
            }, {
              title: 'Actions',
              data: null,
              className: "ui-text-center",
              "fnCreatedCell": function(nTd, sData, oData, iRow, iCol) {
                $(nTd).empty();
                $(nTd).append('<a href="response.php?response=' + oData.id + '&view=details" class="uk-button uk-button-primary">Details</a>');
              },
            }]
          });
        }
      });
    }
    
    $('.export-button').click(function() {
      var data = eval($(this).attr('id'));
      
      var filteredData = [];
      
      $.each(data, function(index, value) {
        
        filteredData[index] = {};
        
        $.each(value.members, function(i, v) {
          filteredData[index].memberName = v.name;
          filteredData[index].memberEmail = v.email;
          filteredData[index].memberPhone = v.number;
        });
        
        filteredData[index].teamName = data[index].name;
        filteredData[index].teamPhone = data[index].phone;
        filteredData[index].teamStatement = data[index].statement;
      });

      JSONToCSVConvertor(filteredData, $(this).attr('id'), true);
    });
    
    function JSONToCSVConvertor(JSONData, ReportTitle, ShowLabel) {
    //If JSONData is not an object then JSON.parse will parse the JSON string in an Object
    var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
    
    var CSV = '';    
    //Set Report title in first row or line
    
    CSV += ReportTitle + '\r\n\n';

    //This condition will generate the Label/Header
    if (ShowLabel) {
        var row = "";
        
        //This loop will extract the label from 1st index of on array
        for (var index in arrData[0]) {
            
            //Now convert each value to string and comma-seprated
            row += index + ',';
        }

        row = row.slice(0, -1);
        
        //append Label row with line break
        CSV += row + '\r\n';
    }
    
    //1st loop is to extract each row
    for (var i = 0; i < arrData.length; i++) {
        var row = "";
        
        //2nd loop will extract each column and convert it in string comma-seprated
        for (var index in arrData[i]) {
            row += '"' + arrData[i][index] + '",';
        }

        row.slice(0, row.length - 1);
        
        //add a line break after each row
        CSV += row + '\r\n';
    }

    if (CSV == '') {        
        alert("Invalid data");
        return;
    }   
    
    //Generate a file name
    var fileName = "MyReport_";
    //this will remove the blank-spaces from the title and replace it with an underscore
    fileName += ReportTitle.replace(/ /g,"_");   
    
    //Initialize file format you want csv or xls
    var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
    
    // Now the little tricky part.
    // you can use either>> window.open(uri);
    // but this will not work in some browsers
    // or you will not get the correct file extension    
    
    //this trick will generate a temp <a /> tag
    var link = document.createElement("a");    
    link.href = uri;
    
    //set the visibility hidden so it will not effect on your web-layout
    link.style = "visibility:hidden";
    link.download = fileName + ".csv";
    
    //this part will append the anchor tag and remove it after automatic click
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
    
    
  </script>
</body>

</html>