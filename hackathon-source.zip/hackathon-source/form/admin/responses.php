<?php require_once'assets/session.php' ?>

<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Rise Hackathon | Admin - Responses</title>
  <meta name="description" content="Rise Hackathon">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include 'assets/header.php' ?>
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->

  <?php include 'assets/topbar.php' ?>
    <div class="topbar second addon">
      <nav class="uk-navbar uk-container">
        <ul class="uk-navbar-nav" style="width: 100%;">  
        <?php if (($_SESSION["user_group"] == 1) || ($_SESSION["user_group"] == 2) || ($_SESSION["user_group"] == 3)): ?>
          <li class="stage-1"><a href="responses.php?stage=1">Stage I</a></li>
          <li class="stage-2"><a href="responses.php?stage=2">Stage II</a></li>
          <li class="stage-3"><a href="responses.php?stage=3">Semi-Finals</a></li>
          <li class="stage-4"><a href="responses.php?stage=4">Final</a></li>
        <?php elseif (($_SESSION["user_group"] == 4)): ?>

        <?php elseif (($_SESSION["user_group"] == 5)): ?>
          <li class="stage-3"><a href="responses.php?stage=3">Semi-Finals</a></li>
          <li class="stage-4"><a href="responses.php?stage=4">Final</a></li>
        <?php endif; ?>
          <li class="uk-float-right" style="float: right;"><a href="responses_table.php">Search</a></li>
        </ul>
      </nav>  
    </div>

  <div class="responseList uk-container white uk-margin-large-top">
    <div class="challengeList">
      <div class="uk-panel uk-panel-box uk-contrast">
        <h3 class="uk-panel-title uk-clearfix">Statements <a id="menuIcon" href="#" class="uk-icon-hover uk-icon-bars uk-float-right"></a></h3>
        <ul id="challengeList" class="uk-nav uk-nav-side uk-nav-parent-icon" data-uk-nav="">
          <li class="challenge" data-id="1"><a href="#">World 1</a></li>
          <li class="challenge" data-id="2"><a href="#">World 2</a></li>
          <li class="challenge" data-id="3"><a href="#">World 3</a></li>
        </ul>
      </div>
    </div>
    <div class="responses">
      <div class="challengeDetails">
        <a id="menuIcon2" href="#" class="uk-icon-hover uk-icon-bars uk-icon-small"></a>
        <div id="title" class="responseTitle"></div>
        <select id="location" style="float: right">
          <option value="Mumbai">Mumbai</option>
          <option value="Manchester">Manchester</option>
        </select>
        <div class="uk-text-muted">
          <span id="total"></span>
<!--           <a id="export" href="#" class="uk-button uk-button-primary uk-button-small uk-float-right">Export Data</a> -->
        </div>
      </div>
      <div id="responseAlert" class="uk-alert uk-alert-warning"></div>
      <div id="responseTable"></div>
    </div>

  </div>

  <?php include 'assets/footer.php' ?>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

  <script>
    var stage = parseInt(getUrlParameter('stage'));
    var world = getUrlParameter('world');
    var loc = getUrlParameter('loc');
    
    locationFilter(loc);
    
    $('li.stage-' + stage).addClass('uk-active');
    
    var responses = '';

    function getResponses(id) {
      $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: {
          cmd: "getResponses",
          data: id + ',' + stage,
          user: user
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          responses = data.data;
          responses.sort(function(a,b) {
            return a.score-b.score
          });
          responses.reverse();

          $("#responseTable").empty();

          if (data.data.length > 0) {

            var total = data.data.length;

            if (total > 1) {
              total = total + ' Responses';
            } else {
              total = total + ' Response';
            }

            $("#responseTable").show();
            $('#responseAlert').hide();
            $('#total').html(total);
            
            $.each(responses, function(index, value) {
              var score = '-';
              var logo = 'assets/img/placeholder.svg';
              var scoreCard = '';
              var pushButton = '';

              if (value.score) {
                score = Math.round(value.score * 100) / 100;
              }
              
              if (value.logo != '') {
                logo = '../upload/' + value.id + '/' + value.logo;
              }
              
              switch (stage) {
                case 1:
                  pushButton = '<button class="uk-button uk-button-success" onClick="pushResponse(2,\''+value.id+'\',\'list\')">Push to Stage II</button>';
                  break;
                case 2:

                  break;
                case 3:
                  pushButton = '<button class="uk-button uk-button-success" onClick="pushResponse(4,\''+value.id+'\',\'list\')">Push to Final</button>';
                  if (value.zero_check == '1') {
                    scoreCard = '<div class="uk-width-1-10 average-score average-score-red"><span>' + score + '</span></div>';
                  } else {
                    scoreCard = '<div class="uk-width-1-10 average-score"><span>' + score + '</span></div>';
                  }
                  break;
                case 4:
                  if (value.zero_check == '1') {
                    scoreCard = '<div class="uk-width-1-10 average-score average-score-red"><span>' + score + '</span></div>';
                  } else {
                    scoreCard = '<div class="uk-width-1-10 average-score"><span>' + score + '</span></div>';
                  }
                  break;
                default:

              }
              
              <?php if (($_SESSION["user_group"] == 3) || ($_SESSION["user_group"] == 2)): ?>
                if (stage == 3) {
                  pushButton = '';
                }
              <?php endif; ?>

              $("#responseTable").append(
                '<div class="response-row" data-id="' + value.id + '" data-location="' + value.location + '">' +
                  '<div class="uk-grid">' +
                    '<div class="uk-width-2-10 responseImage" ><img src="' + logo + '"></div>' +
                    '<div class="uk-width-7-10 text-wrap-normal">' +
                      '<h3 class="company-name">' + value.name + '</h3><span class="tag-line">' + value.idea + '</span>' +
                      '<div class="short-desc">' + value.benefit + '</div>' +
                    '</div>' +
                    scoreCard  +
                  '</div>' +
                  '<div class="response-actions">' +
                    '<a class="uk-button uk-button-primary" href="response.php?response=' + value.id + '&view=details">Details</a>' +   
                    <?php if (($_SESSION["user_group"] == 1)): ?>
                      '<button class="uk-button uk-button-danger" onClick="deleteResponse(\''+value.id+'\')">Delete</button>' +
                    <?php endif; ?>  
                    <?php if (($_SESSION["user_group"] == 1) || ($_SESSION["user_group"] == 2) || ($_SESSION["user_group"] == 3) || ($_SESSION["user_group"] == 4)): ?>
                      pushButton +
                    <?php endif; ?>  
                  '</div>' +
                '</div>'
              );
            });            
          } else {
            $("#responseTable").hide();
            $('#responseAlert').show();
            $('#responseAlert').text('No responses for this statement.');
            $('#total').empty();
          }
          locationFilter(loc);
        }
      });
    }
    
    $('#location').on('change', function(e) {
      window.location.href = 'responses.php?stage=' + stage + '&world=' + world + '&loc=' + $('#location').val();
    });
    
    function locationFilter(loc) {
      
      if (!loc || loc == 'undefined') {
        loc = 'Mumbai';
      }
      
      
      $('#location').val(loc);
      
      $("#responseTable").show(); 
      $('#responseAlert').hide();
      $('#responseTable .response-row').hide();
      $('#responseTable .response-row[data-location="'+ $('#location').val() +'"]').show();
      var total = $('#responseTable .response-row:visible').length;
      
      if (total == 0) {
        $("#responseTable").hide(); 
        $('#responseAlert').show();
        $('#responseAlert').text('No responses for this statement.');
        $('#total').empty();
      } else {
       
        if (total > 1) {
          total = total + ' Responses';
        } else {
          total = total + ' Response';
        }
      
        $('#total').html(total);
      }
    }

    $("#challengeList").on('click', '.challenge', function(e) {
      e.preventDefault();
      
      window.location.href = 'responses.php?stage=' + stage + '&world=' + $(this).text() + '&loc=' + loc;

    });
    
    function selectStatement(world) {
      var self = $("#challengeList li:contains('"+world+"')");
      
      if(!world || world == 'undefined') {
        self = $("#challengeList li:contains('World 1')");
      }
      
      $("#challengeList li").removeClass("uk-active");
            
      self.addClass("uk-active");

      $('#title').text(self.text());
      
      var statementId = self.data('id');

      getResponses(statementId);
    }

    selectStatement(world);
    
    var menu = $('.challengeList');

    $('#menuIcon').on('click', function(e) {
      e.preventDefault();
      menu.toggle('slide', function() {
        $('.responses').css('width', '100%');
        $('.challengeDetails #title, .challengeDetails .uk-text-muted').animate({
          'padding-left': '100px'
        }, function() {
          $('#menuIcon2').fadeIn();
        });
      });
    });

    $('#menuIcon2').on('click', function(e) {
      e.preventDefault();
      $('.responses').css('width', '75%');

      setTimeout(function() {
        menu.toggle('slide', function() {
          $('#menuIcon2').fadeOut(function() {
            $('.challengeDetails #title, .challengeDetails .uk-text-muted').animate({
              'padding-left': '0'
            });
          });
        });
      }, 250);
    });

    function deleteResponse(id) {
      var row = $('.response-row[data-id="' + id + '"]');
      var confirm = false;

      UIkit.modal.confirm("Are you sure?", function() {

        $.ajax({
          method: "POST",
          url: "../api.php",
          dataType: "json",
          data: {
            cmd: "deleteResponse",
            data: id,
            user: user
          },
          error: function(data) {
            console.log("Error");
            console.log(data);
          },
          success: function(data) {
            UIkit.notify('<i class="uk-icon-check"></i> ' + data.data, {
              status: 'success'
            });
            $(row).fadeOut("slow", function() {
              row.remove();
            });

          }
        });
      });
    }
       
    $('#responseTable').on('click', '.response-row', function(e) {
      if (!$(e.target).closest('button').length) {
        window.location.href = 'response.php?response=' + $(this).data('id') + '&view=details';
      }
    });

  </script>
</body>

</html>