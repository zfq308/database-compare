<?php require_once'assets/session.php' ?>

<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Rise Challenges | Admin - Users</title>
  <meta name="description" content="Rise Challenges">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include 'assets/header.php' ?>
</head>

<body>

  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
  <?php include 'assets/topbar.php' ?>

  <div class="uk-container white uk-margin-large-top uk-hidden-">

    <ul class="uk-text-center" data-uk-switcher="{connect:'#usersAndGroupsList', animation: 'fade'}" style="padding-left: 0">
      <?php if ($_SESSION["user_role"] == 'super_admin'): ?>
<!--       <button id="menuDetails" class="uk-button uk-button-primary uk-button-large">Users</button>
      <button id="menuNotes" class="uk-button uk-button-primary uk-button-large">Groups</button> -->
      <?php endif; ?>
    </ul>

    <ul id="usersAndGroupsList" class="uk-switcher">
      <li id="userList">
        <a href="#newUser" class="uk-button uk-button-primary uk-button-large uk-float-right" data-uk-modal>Add User</a>
        <table id="userTable" class="uk-table uk-table-hover uk-table-striped" cellspacing="0" width="100%">
          <caption>List of all registered users.</caption>
          <thead>
            <tr>
              <th>Username</th>
              <th>Email</th>
              <th class="userGroup">Group</th>
<!--               <th>Role</th> -->
              <th>Actions</th>
            </tr>
          </thead>
          <tfoot></tfoot>
          <tbody></tbody>
        </table>
      </li>
      <?php if ($_SESSION["user_role"] == 'super_admin'): ?>
      <li id="groupList">
        <a href="#newGroup" class="uk-button uk-button-primary uk-button-large uk-float-right" data-uk-modal>Add Group</a>
        <table class="uk-table uk-table-hover uk-table-striped">
          <caption>List of Admin groups.</caption>
          <thead>
            <tr>
              <th>Name</th>
            </tr>
          </thead>
          <tfoot></tfoot>
          <tbody></tbody>
        </table>
      </li>
      <?php endif; ?>
    </ul>

  </div>

  <div id="newUser" class="uk-modal">
    <div class="uk-modal-dialog">
      <a class="uk-modal-close uk-close"></a>
      <div class="uk-modal-header">
        <h2>Add New User</h2></div>
      <form id="userForm" class="uk-form uk-width-1-1">
        <fieldset>
          <div class="uk-form-row">
            <label class="uk-form-label" for="username">Username </label><span class="uk-text-small uk-text-muted"> (only letters and numbers, 2 to 64 characters)</span>
            <input name="username" type="text" placeholder="Username" class="uk-width-1-1">
            <div id="usernameAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
          <div class="uk-form-row">
            <label class="uk-form-label" for="email">Email</label>
            <input name="email" type="text" placeholder="Email" class="uk-width-1-1">
            <div id="emailAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
          <div class="uk-form-row">
            <label class="uk-form-label" for="password">Password </label><span class="uk-text-small uk-text-muted"> (min. 6 characters)</span>
            <input name="password" type="password" placeholder="Password" class="uk-width-1-1">
            <div id="passwordAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
          <div class="uk-form-row">
            <label class="uk-form-label" for="passwordRepeat">Repeat Password</label>
            <input name="passwordRepeat" type="password" placeholder="Repeat Password" class="uk-width-1-1">
            <div id="passwordRepeatAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
          <div class="uk-form-row">
            <label class="uk-form-label" for="passwordRepeat">Admin Group</label><br>
            <select name="group" class="uk-width-1-3"></select>
            <div id="groupAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
<!--           <div class="uk-form-row">
            <label class="uk-form-label" for="passwordRepeat">Admin Role</label><br>
            <select name="role" class="uk-width-1-3">
            <option value="user">User</option>
            <option value="group_admin">Group Admin</option>
            <option value="super_admin">Super Admin</option>
          </select>
            <div id="roleAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div> -->
        </fieldset>
      </form>
      <div class="uk-modal-footer uk-text-right">
        <a href="#" class="cancelButton uk-button uk-margin-top uk-modal-close">Cancel</a>
        <a id="addUserButton" href="#" class="uk-button uk-button-primary uk-margin-top">Add User</a>
      </div>
    </div>
  </div>

  <div id="newGroup" class="uk-modal">
    <div class="uk-modal-dialog">
      <a class="uk-modal-close uk-close"></a>
      <div class="uk-modal-header">
        <h2>Add New Group</h2></div>
      <form id="groupForm" class="uk-form uk-width-1-1">
        <fieldset>
          <div class="uk-form-row">
            <label class="uk-form-label" for="groupName">Name </label><span class="uk-text-small uk-text-muted"> (only letters and numbers, 2 to 64 characters)</span>
            <input name="groupName" type="text" placeholder="Username" class="uk-width-1-1">
            <div id="groupNameAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
        </fieldset>
      </form>
      <div class="uk-modal-footer uk-text-right">
        <a href="#" class="cancelButton uk-button uk-margin-top uk-modal-close">Cancel</a>
        <a id="addGroupButton" href="#" class="uk-button uk-button-primary uk-margin-top">Add Group</a>
      </div>
    </div>
  </div>

  <div id="updateUser" class="uk-modal">
    <div class="uk-modal-dialog">
      <a class="uk-modal-close uk-close"></a>
      <div class="uk-modal-header">
        <h2>Edit User</h2></div>
      <form id="updateUserForm" class="uk-form uk-width-1-1">
        <fieldset>
          <div class="uk-form-row">
            <label class="uk-form-label" for="username">Username </label><span class="uk-text-small uk-text-muted"> (only letters and numbers, 2 to 64 characters)</span>
            <input name="username" type="text" placeholder="Username" class="uk-width-1-1">
            <div id="usernameAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
          <div class="uk-form-row">
            <label class="uk-form-label" for="email">Email</label>
            <input name="email" type="text" placeholder="Email" class="uk-width-1-1">
            <div id="emailAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
          <div class="uk-form-row">
            <label class="uk-form-label" for="password">Password </label><span class="uk-text-small uk-text-muted"> (min. 6 characters)</span>
            <input name="password" type="password" placeholder="Password" class="uk-width-1-1">
            <div id="passwordAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
          <div class="uk-form-row">
            <label class="uk-form-label" for="passwordRepeat">Repeat Password</label>
            <input name="passwordRepeat" type="password" placeholder="Repeat Password" class="uk-width-1-1">
            <div id="passwordRepeatAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
          <div class="uk-form-row">
            <label class="uk-form-label" for="passwordRepeat">Admin Group</label><br>
            <select name="group" class="uk-width-1-3"></select>
            <div id="groupAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div>
<!--           <div class="uk-form-row">
            <label class="uk-form-label" for="passwordRepeat">Admin Role</label><br>
            <select name="role" class="uk-width-1-3">
              <option value="user">User</option>
              <option value="group_admin">Group Admin</option>
              <option value="super_admin">Super Admin</option>
            </select>
            <div id="roleAlert" class="uk-alert uk-alert-danger" style="display: none"></div>
          </div> -->
        </fieldset>
      </form>
      <div class="uk-modal-footer uk-text-right">
        <a href="#" class="cancelButton uk-button uk-margin-top uk-modal-close">Cancel</a>
        <a id="updateUserButton" href="#" class="uk-button uk-button-primary uk-margin-top">Edit User</a>
      </div>
    </div>
  </div>

  <?php include 'assets/footer.php' ?>
  <script src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
  <script>
    getUsers();
    getGroups();

    function getUsers() {
      $('#userTable').DataTable().destroy();
      var currentGroup = '<?php echo $_SESSION["user_group"] ?>';
      var currentRole = '<?php echo $_SESSION["user_role"] ?>';

      $('#userList tbody').empty();

      manageUsers('getUsers', 'all', user).done(function(data) {
        var users = data.data;
        if (data.data.length > 0) {
          $.each(users, function(index, value) {
            $('#userList tbody').append(
              '<tr data-id="' + value.user_id + '" data-group-id="' + value.user_group + '" data-role="' + value.user_role + '"">' +
              '<td>' + value.user_name + '</td>' +
              '<td>' + value.user_email + '</td>' +
              '<td class="userGroup">' + value.group_name + '</td>' +
//               '<td class="userRole">' + value.user_role.replace(/_/g, ' ') + '</td>' +
              '<td width="120">' +
              '<button class="uk-button uk-button-primary uk-margin-small-right update-button">Edit</button>' +
              '<button class="uk-button uk-button-primary delete-button">Delete</button>' +
              '</td>' +
              '</tr>'
            );
          });
          if (currentRole == 'group_admin') {
            $('.userGroup').hide();
          }
                  
          $('#userTable').DataTable({
            "info": false,
          });
          
//           $('.paginate_button.disabled').addClass('uk-button');
//           $('.paginate_button.current').addClass('uk-button uk-button-primary');
//           $('.paginate_button').addClass('uk-button');
          
        }
      }).fail(function(data) {
        console.log("Error");
        $('#userList').append('<div class="uk-alert" data-uk-alert><a href="" class="uk-alert-close uk-close"></a><p>' + data + '</p></div>');
      });
    }

    function addUser(data) {
      manageUsers('addUser', data, user).done(function(data) {

        if (data.status == 'error') {
          UIkit.notify(data.data, {
            status: 'danger'
          });
        }
        if (data.status == 'success') {

          var modal = UIkit.modal("#newUser");
          if (modal.isActive()) {
            modal.hide();
          }
          
          UIkit.notify(data.data, {
            status: 'success'
          });
          $('#userForm')[0].reset();
          getUsers();
        }

      }).fail(function(data) {
        console.log("Error");
        console.log(data);
      });
    }

    function deleteUser(data) {
      manageUsers('deleteUser', data, user).done(function(data) {

        UIkit.notify(data.data, {
          status: 'success'
        })
        getUsers();

      }).fail(function(data) {
        console.log("Error");
        console.log(data);
      });
    }

    function updateUser(data) {
      manageUsers('updateUser', data, user).done(function(data) {
                
        if (data.status == 'error') {
          UIkit.notify(data.data, {
            status: 'danger'
          });
        }
        
        if (data.status == 'success') {
          
          var modal = UIkit.modal("#updateUser");
          if (modal.isActive()) {
            modal.hide();
          }
          
          UIkit.notify(data.data, {
            status: 'success'
          });
          getUsers();
        }

      }).fail(function(data) {
         UIkit.notify(data.data, {
          status: 'danger'
        })
        getUsers();
      });
    }

    function getGroups() {
      $('#groupList tbody').empty();
      manageUsers('getGroups', 'all', user).done(function(data) {
        var groups = data.data;
        var currentGroup = '<?php echo $_SESSION["user_group"] ?>';
        var currentRole = '<?php echo $_SESSION["user_role"] ?>';

        if (data.data.length > 0) {
          $.each(groups, function(index, value) {
            $('#groupList tbody').append(
              '<tr data-id="' + value.group_id + '">' +
              '<td>' + value.group_name + '</td>' +
              '<td width="65">' +
              '<button data-id="" class="uk-button uk-button-primary delete-button">Delete</button>' +

              '</td>' +
              '</tr>'
            );

            if (currentRole == 'group_admin') {
              $('#userForm select[name="group"]').append($("<option></option>").attr("value", value.group_id).text(value.group_name));
              $('#userForm select[name="group"] option[value=' + currentGroup + ']').prop('selected', 'selected');
              $('#userForm select').parent().hide();

              $('#updateUserForm select[name="group"]').append($("<option></option>").attr("value", value.group_id).text(value.group_name));
            } else {
              $('#userForm select[name="group"]').append($("<option></option>").attr("value", value.group_id).text(value.group_name));
              $('#updateUserForm select[name="group"]').append($("<option></option>").attr("value", value.group_id).text(value.group_name));
            }

          });
        }
      }).fail(function(data) {
        console.log("Error");
        $('#groupList').append('<div class="uk-alert" data-uk-alert><a href="" class="uk-alert-close uk-close"></a><p>' + data + '</p></div>');
      });
    }

    function addGroup($data) {
      manageUsers('addGroup', $data, user).done(function(data) {

        var modal = UIkit.modal("#newGroup");
        if (modal.isActive()) {
          modal.hide();
        }
        UIkit.notify(data.data, {
          status: 'success'
        })
        getGroups();

      }).fail(function(data) {
        console.log("Error");
        console.log(data);
      });
    }

    function deleteGroup($data) {
      manageUsers('deleteGroup', $data, user).done(function(data) {

        if (data.status == 'error') {
          UIkit.notify(data.data, {
            status: 'danger'
          });
        }
        if (data.status == 'success') {        
          UIkit.notify(data.data, {
            status: 'success'
          });
          getGroups();
        }

      }).fail(function(data) {
        console.log("Error");
        console.log(data);
      });
    }

    function manageUsers(cmd, data, user) {
      data = {
        'cmd': cmd,
        'data': data,
        'user': user,
      }

      return $.ajax({
        method: "POST",
        url: "../api.php",
        dataType: "json",
        data: data,
      });
    }

//     var userGroup = $('#userForm select[name="group"]');
//     var role = $('#userForm select[name="role"]');

    var groupName = $('#groupForm input[name="groupName"]');

    var userValidation = [false, false, false, false];
    var groupValidation = [false];

    $('#addUserButton').on('click', function(e) {
      e.preventDefault();
      if (userValidation.every(isTrue) && userValidation.length > 0) {
        var form = $('#userForm');
        var array = jQuery(form).serializeArray();
        var json = JSON.stringify(array);
        addUser(json);
      } else {
        $('#userForm input[name="username"]').trigger('change');
        $('#userForm input[name="email"]').trigger('change');
        $('#userForm input[name="password"]').trigger('change');
        $('#userForm input[name="passwordRepeat"]').trigger('change');
      }
    });

    $('#addGroupButton').on('click', function(e) {
      e.preventDefault();
      if (groupValidation.every(isTrue) && groupValidation.length > 0) {
        var form = $('#groupForm');
        var array = jQuery(form).serializeArray();
        var json = JSON.stringify(array);
        addGroup(json);
      } else {
        groupName.trigger('change');
      }

    });

    $('#updateUserButton').on('click', function(e) {
      e.preventDefault();
      
      if (userValidation[0] && userValidation[1]) {
        var form = $('#updateUserForm');  
        var array = jQuery(form).serializeArray();
        array.push({"name":"id","value":form.data('id')});
        var json = JSON.stringify(array);
        updateUser(json);
      } else {
        $('#updateUserForm input[name="username"]').trigger('change');
        $('#updateUserForm input[name="email"]').trigger('change');
        $('#updateUserForm input[name="password"]').trigger('change');
        $('#updateUserForm input[name="passwordRepeat"]').trigger('change');
      }
    });

    $('#userForm input[name="username"]').on('change', function(e) {
      userValidation[0] = validateUsername($('#userForm'));
    });
    
    $('#updateUserForm input[name="username"]').on('change', function(e) {
      userValidation[0] = validateUsername($('#updateUserForm'));
    });

    function validateUsername(form) {
      var username = form.find('input[name="username"]');
      var valid = false;
      var regx = /^[A-Za-z0-9]+$/;
      var usernameAlert = "";

      if (username.val() == '') {
        usernameAlert += "Please enter username!<br>";
      } else if (!regx.test(username.val())) {
        usernameAlert += "Only letters and numbers are allowed!<br>";
      } else if (username.val().length < 2 || username.val().length > 64) {
        usernameAlert += "Only 2 to 64 characters are allowed!<br>";
      } else {
        valid = true;
      }

      if (valid) {
        username.removeClass('uk-form-danger');
        form.find('#usernameAlert').slideUp();
      } else {
        username.addClass('uk-form-danger');
        form.find('#usernameAlert').html(usernameAlert);
        form.find('#usernameAlert').slideDown();
      }

      return valid;
    };

    $('#userForm input[name="email"]').on('change', function(e) {
      userValidation[1] = validateEmail($('#userForm'));
    });
    
    $('#updateUserForm input[name="email"]').on('change', function(e) {
      userValidation[1] = validateEmail($('#updateUserForm'));
    });

    function validateEmail(form) {
      var email = form.find('input[name="email"]');
      var valid = false;
      var emailAlert = "";

      if (email.val() == '') {
        emailAlert += "Please enter email!<br>";
      } else if (validateEmailFormat(email.val()) !== true) {
        emailAlert += "Please enter valid email address!<br>";
      } else {
        valid = true;
      }

      if (valid) {
        email.removeClass('uk-form-danger');
        form.find('#emailAlert').slideUp();
      } else {
        email.addClass('uk-form-danger');
        form.find('#emailAlert').html(emailAlert);
        form.find('#emailAlert').slideDown();
      }

      return valid;
    }

    function validateEmailFormat(email) {
      var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(email);
    }

    $('#userForm input[name="password"]').on('change', function(e) {
      userValidation[2] = validatePassword($('#userForm'));
    });

    function validatePassword(form) {
      var password = form.find('input[name="password"]');
      var valid = false;
      var passwordAlert = "";

      if (password.val() == '') {
        passwordAlert += "Please enter password!<br>";
      } else if (password.val().length < 6) {
        passwordAlert += "Enter at least 6 characters!<br>";
      } else {
        valid = true;
      }

      if (valid) {
        password.removeClass('uk-form-danger');
        form.find('#passwordAlert').slideUp();
      } else {
        password.addClass('uk-form-danger');
        form.find('#passwordAlert').html(passwordAlert);
        form.find('#passwordAlert').slideDown();
      }

      return valid;

    }

    $('#userForm input[name="passwordRepeat"]').on('change', function(e) {
      userValidation[3] = validatePasswordRepeat($('#userForm'));
    });

    function validatePasswordRepeat(form) {
      var password = form.find('input[name="password"]');
      var passwordRepeat = form.find('input[name="passwordRepeat"]');
      var valid = false;
      var passwordRepeatAlert = "";

      if (passwordRepeat.val() == '') {
        passwordRepeatAlert += "Please enter password!<br>";
      } else if (passwordRepeat.val() != password.val()) {
        passwordRepeatAlert += "Entered passwords do not match!<br>";
      } else {
        valid = true;
      }

      if (valid) {
        passwordRepeat.removeClass('uk-form-danger');
        form.find('#passwordRepeatAlert').slideUp();
      } else {
        passwordRepeat.addClass('uk-form-danger');
        form.find('#passwordRepeatAlert').html(passwordRepeatAlert);
        form.find('#passwordRepeatAlert').slideDown();
      }

      return valid;
    }
    
    $('#updateUserForm input[name="password"]').on('change', function(e) {
      userValidation[2] = validateUpdatePassword($('#updateUserForm'));
    });
    
    function validateUpdatePassword(form) {
      var password = form.find('input[name="password"]');
      var valid = false;
      var passwordAlert = "";

      if (password.val() != '') {
        if (password.val().length < 6) {
          passwordAlert += "Enter at least 6 characters!<br>";
        } else {
          valid = true;
        }
      } else {
        valid = true;
      }

      if (valid) {
        password.removeClass('uk-form-danger');
        form.find('#passwordAlert').slideUp();
      } else {
        password.addClass('uk-form-danger');
        form.find('#passwordAlert').html(passwordAlert);
        form.find('#passwordAlert').slideDown();
      }

      return valid;
    }
    
    $('#updateUserForm input[name="passwordRepeat"]').on('change', function(e) {
      userValidation[3] = validateUpdatePasswordRepeat($('#updateUserForm'));
    });
    
    function validateUpdatePasswordRepeat(form) {
      var password = form.find('input[name="password"]');
      var passwordRepeat = form.find('input[name="passwordRepeat"]');
      var valid = false;
      var passwordRepeatAlert = "";

      if (passwordRepeat.val() != password.val()) {
        passwordRepeatAlert += "Entered passwords do not match!<br>";
      } else {
        valid = true;
      }

      if (valid) {
        passwordRepeat.removeClass('uk-form-danger');
        form.find('#passwordRepeatAlert').slideUp();
      } else {
        passwordRepeat.addClass('uk-form-danger');
        form.find('#passwordRepeatAlert').html(passwordRepeatAlert);
        form.find('#passwordRepeatAlert').slideDown();
      }

      return valid;
    }

    groupName.on('change', function(e) {
      var valid = false;
      var regx = /^[A-Za-z0-9_ ]+$/;
      var groupNameAlert = "";

      if (groupName.val() == '') {
        groupNameAlert += "Please enter a name for group!<br>";
      } else if (!regx.test(groupName.val())) {
        groupNameAlert += "Only letters and numbers are allowed!<br>";
      } else if (groupName.val().length < 2 || groupName.val().length > 64) {
        groupNameAlert += "Only 2 to 64 characters are allowed!<br>";
      } else {
        valid = true;
      }

      if (valid) {
        groupName.removeClass('uk-form-danger');
        $('#groupNameAlert').slideUp();
      } else {
        groupName.addClass('uk-form-danger');
        $('#groupNameAlert').html(groupNameAlert);
        $('#groupNameAlert').slideDown();
      }

      groupValidation[0] = valid;

    });

    function isTrue(element, index, array) {
      return element == true;
    }

    $('#userList table').on('click', '.delete-button', function(e) {
      e.preventDefault();
      var id = $(this).parents('tr').data('id');
      UIkit.modal.confirm('Are you sure? User to delete: "' + $(this).parents('tr').children('td').eq(0).text() + '".', function() {
        deleteUser(id);
      });
    });

    $('#groupList table').on('click', '.delete-button', function(e) {
      e.preventDefault();
      var id = $(this).parents('tr').data('id');
      UIkit.modal.confirm('Are you sure? Group to delete: "' + $(this).parents('tr').children('td').eq(0).text() + '".', function() {
        deleteGroup(id);
      });
    });

    $('#userList table').on('click', '.update-button', function(e) {
      e.preventDefault();
      var id = $(this).parents('tr').data('id');
      var username = $(this).parents('tr').children('td').eq(0).text();
      var email = $(this).parents('tr').children('td').eq(1).text();
      var group = $(this).parents('tr').data('group-id');
      var role = $(this).parents('tr').data('role');
      $('#updateUserForm').data('id', id);
      $('#updateUser input[name=username]').val(username);
      $('#updateUser input[name=email]').val(email);
      $('#updateUser input[name=password]').val('');
      $('#updateUser input[name=passwordRepeat]').val('');
      $('#updateUser select[name=role] option[value=' + role + ']').prop('selected', 'selected');
      $('#updateUser select[name=group] option[value=' + group + ']').prop('selected', 'selected');

      var modal = UIkit.modal("#updateUser");

      if (modal.isActive()) {
        modal.hide();
      } else {
        modal.show();
        $('#updateUserForm input[name="username"]').trigger('change');
        $('#updateUserForm input[name="email"]').trigger('change');
        $('#updateUserForm input[name="password"]').trigger('change');
        $('#updateUserForm input[name="passwordRepeat"]').trigger('change');
      }
    });
  </script>
</body>

</html>