<?php require_once'assets/session.php' ?>

<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Rise Challenges | Admin - Responses</title>
  <meta name="description" content="Rise Challenges">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include 'assets/header.php' ?>
</head>

<body>
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

  <?php include 'assets/topbar.php' ?>

  <div class="uk-container white uk-margin-large-top">

    <ul class="uk-text-center" data-uk-switcher="{connect:'#responseDetails', animation: 'fade'}" style="padding-left: 0">
      <button id="menuDetails" class="uk-button uk-button-primary uk-button-large">Details</button>
      <button id="menuNotes" class="uk-button uk-button-primary uk-button-large">Notes</button>
    </ul>

    <ul id="responseDetails" class="uk-switcher uk-margin-large-top">
      <li id="response">
        <table class="uk-table uk-table-hover uk-table-striped">
          <caption>Data submitted in response form.</caption>
          <thead>
            <tr>
              <th>Property</th>
              <th>Value</th>
            </tr>
          </thead>
          <tfoot></tfoot>
          <tbody></tbody>
        </table>
      </li>
      <li id="notes">
        <div class="uk-form-row">
          <textarea id="newNote" rows="8" placeholder="Enter your note here" class="uk-width-1-1"></textarea>
          <button id="addNote" class="uk-button uk-button-primary uk-button-large" style="margin: 0 auto; display: block">Add Note</button>
        </div>

        <div id="noteList" class="uk-margin-large-top"></div>

      </li>
    </ul>

  </div>

  <?php include 'assets/footer.php' ?>
  <script>
    var view = getUrlParameter('view');
    var challenge = getUrlParameter('challenge');
    var response = getUrlParameter('response');

    getNotes();

    if (view == 'notes') {
      $('#menuNotes').addClass('uk-active');
    }

    $.ajax({
      method: "POST",
      url: "../api/index.php",
      dataType: "json",
      data: {
        cmd: "getResponseData",
        data: challenge + ", " + response,
        user: user
      },
      error: function(data) {
        console.log("Error");
        console.log(data);
      },
      success: function(data) {
        var predefinedData = '<form-template><fields><field class="form-control" label="Company Name" name="company-name" placeholder="Company &amp;amp; Co LTD" required="true" type="text" subtype="text"></field><field class="form-control text-input" label="Company Tag-Line" name="text-1460124861998" placeholder="Mythical Creations" required="true" type="text" subtype="text"></field><field class="form-control" label="Company Description" maxlength="140" name="company-description" required="true" type="textarea"></field><field class="form-control file-input" label="Company Logo" name="company-logo" required="true" type="file"></field><field class="form-control text-input" label="Contact Email" name="company-email" placeholder="email@example.com" required="true" type="text" subtype="email"></field><field class="form-control" label="Company Website" name="company-website" placeholder="http://www.example.com/" required="true" type="text" subtype="text"></field><field class="form-control text-input" label="USP 1" name="usp1" required="true" type="text" subtype="text"></field><field class="form-control text-input" label="USP 2" name="usp2" required="true" type="text" subtype="text"></field><field class="form-control text-input" label="USP 3" name="usp3" required="true" type="text" subtype="text"></field>';
        
        var formData = jQuery.parseJSON(JSON.stringify(xmlToJson(jQuery.parseXML(data.data[0].challenge_form.replace(/\s\s+/g, ' ').replace("<form-template> <fields>", predefinedData)))));
        var responseData = jQuery.parseJSON(data.data[0].response_data);      
        var fields = formData["form-template"].fields.field;
        var files = jQuery.parseJSON(data.data[0].response_attachments);
        var challengeId = data.data[0].challenge_id;
        var assetsId = data.data[0].response_assets_id;
        var submitted = 0;
        var imagePointer = 0;

        var responseFormatted = {};
        
        $.each(responseData, function(index, value) {
          responseFormatted[value.name] = value.value;
        });
                  
        $.each(fields, function(index, value) {
          var field = value['@attributes'];
          console.log(field);
          //field.label, field.type, responseFormatted[field.name]

          var row = '<tr><td>'+field.label+'</td>';

            if (field.type=='file') {
              row += '<td><a href="../upload/' + challengeId + '/response/' + assetsId + '/' + files[imagePointer] + '" target="_blank">'+files[imagePointer]+'</td></tr>';
              imagePointer++;
              submitted++;
            } else if (responseData[index]) {
              console.log(responseData[index]);
              row += '<td>'+responseFormatted[field.name]+'</td></tr>'; 
            
              if(responseData[index].value) {
                submitted++;
              }

            } else {
              row += '<td></td></tr>';
            }

          $('#response table tbody').append(row);
          
        });

        
        $('#response table tfoot').append('<tr><td>Total fields: '+fields.length+'</td><td>Submitted fields: '+submitted+'</td></tr>');

      }
    });

    $('#addNote').on('click', function() {

      var userId = '<?php echo $_SESSION["user_id"] ?>';

      $.ajax({
        method: "POST",
        url: "../api/index.php",
        dataType: "json",
        data: {
          cmd: "addNote",
          user: user,
          data: $('#newNote').val() + ", " + response
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          UIkit.notify(data.data, {
            status: 'success'
          });
          getNotes();
        }
      });
    });

    function getNotes() {
      $.ajax({
        method: "POST",
        url: "../api/index.php",
        dataType: "json",
        data: {
          cmd: "getNotes",
          user: user,
          data: response
        },
        error: function(data) {
          console.log("Error");
          console.log(data);
        },
        success: function(data) {
          $('#noteList').empty();
          $.each(data.data, function(index, value) {
            
            $('#noteList').append(
              '<article class="uk-comment">' +
                '<header class="uk-comment-header">' +
                  '<img class="uk-comment-avatar" src="http://getuikit.com/docs/images/placeholder_avatar.svg" alt="User avatar">' +
                  '<h4 class="uk-comment-title">' + value.user_name + '</h4>' +
                  '<div class="uk-comment-meta">' + value.note_created + '</div>' +
                '</header>' +
                '<div class="uk-comment-body">' + value.note_content + '</div>' +
              '</article>'
            );
                       
            if (index != (data.data.length - 1)) {
              $('#noteList').append('<hr>');
            }
          });
        }
      });
    }
  </script>

</body>

</html>