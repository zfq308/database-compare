<?php  require_once'assets/session.php' ?>

<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Rise Challenges | Admin - Challenges</title>
  <meta name="description" content="Rise Challenges">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include 'assets/header.php' ?>
</head>

<body>
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

  <?php include 'assets/topbar.php' ?>
  <div id="activeChallenges">
    <div class="uk-container white uk-margin-large-top">
      <?php if ($_SESSION["user_role"] == 'super_admin'): ?>
      <div class="uk-width-1-1 uk-text-center">
        <a href="challenge_manage.php?action=new" class="uk-button uk-button-primary uk-button-large">Add Challenge</a>
        <a href="#" id="archiveButton" class="uk-button uk-button-primary uk-button-large">View Archive</a>
      </div>
      <?php endif; ?>

      <div class="uk-overflow-container">
        <table id="challengeTable" class="uk-table uk-table-hover uk-text-nowrap">
          <thead>
            <tr>
              <th style="min-width:320px">Challenge</th>
              <!-- <th>Description</th> -->
              <th>Deadline</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="archivedChallenges">
    <div class="uk-container white uk-margin-large-top">
      <div class="uk-width-1-1 uk-text-center">
        <a href="#" id="activeButton" class="uk-button uk-button-primary uk-button-large">Active Challenges</a>
      </div>

      <div class="uk-overflow-container">
        <table id="archiveTable" class="uk-table uk-table-hover uk-text-nowrap">
          <thead>
            <tr>
              <th style="min-width:320px">Challenge</th>
              <!-- <th>Description</th> -->
              <th>Deadline</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          </tbody>
        </table>
      </div>
    </div>
  </div>


  <?php include 'assets/footer.php' ?>

  <script>
    challengeList();
    
    $('#challengeTable').on('click', '.archive-button', function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      UIkit.modal.confirm("Are you sure?", function() {
        changeChallenge('archive', id);
      });
    });
    
    $('#archiveTable').on('click', '.restore-button', function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      UIkit.modal.confirm("Are you sure?", function() {
        changeChallenge('restore', id);
      });
    });
    
    $('#archiveTable').on('click', '.delete-button', function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      UIkit.modal.confirm("Are you sure?", function() {
        changeChallenge('delete', id);
      });
    });
    
    $('#archiveButton').on('click', function(e) {
      e.preventDefault();
      $('#activeChallenges').fadeOut(500, function() {
        $('#archivedChallenges').fadeIn(500);
      });
    });

    
    $('#activeButton').on('click', function(e) {
      e.preventDefault();
      $('#archivedChallenges').fadeOut(500, function() {
        $('#activeChallenges').fadeIn(500);
      });
    });

    function challengeList(type) {
      var table = '';
      $.ajax({
        method: 'POST',
        url: '../api/index.php',
        dataType: 'json',
        data: {
          cmd: 'getChallenges',
          data: 'all'
        },
        error: function(data) {
          console.log('Error');
          console.log(data);
        },
        success: function(data) {
          var challenges = data.data;
          if (challenges.length > 0) {

            $.each(challenges, function(index, value) {

              if (value.challenge_status == 'active') {
                $('#challengeTable tbody').append(
                  '<tr>' +
                  '<td class="text-wrap-normal">' + value.challenge_title + '</td>' +
    //               '<td class="text-wrap-normal">' + value.challenge_description + '</td>' +
                  '<td>' + parseDate(value.challenge_deadline, 'formatted') + '</td>' +
                  '<td width="100">' +
                  '<a href="responses.php?id=' + value.challenge_id + '"  class="uk-button uk-button-primary" style="margin-right: 10px">Responses</a>' +
                  '<a href="challenge_manage.php?action=update&id=' + value.challenge_id + '" class="uk-button uk-button-primary" style="margin-right: 10px">Edit</a>' +
                  '<button data-id="' + value.challenge_id + '" class="uk-button uk-button-primary archive-button">Archive</button>' +
                  '</td>' +
                  '</tr>'
                );
              }

              if (value.challenge_status == 'archived') {
                $('#archiveTable tbody').append(
                  '<tr>' +
                  '<td class="text-wrap-normal">' + value.challenge_title + '</td>' +
                  '<td>' + parseDate(value.challenge_deadline, 'formatted') + '</td>' +
                  '<td width="100">' +
                  '<button data-id="' + value.challenge_id + '" class="uk-button uk-button-primary restore-button" style="margin-right: 10px">Restore</button>' +
                  '<button data-id="' + value.challenge_id + '" class="uk-button uk-button-primary delete-button">Delete</button>' +
                  '</td>' +
                  '</tr>'
                );
              }
            });
          }
        }
      });
    }

    function changeChallenge(type, id) {
      var row = $('.'+type+'-button[data-id="'+id+'"]').closest('tr');
      var cmd = type+'Challenge';
      manageChallenge(cmd, id, user).done(function(result) {
        UIkit.notify('<i class="uk-icon-check"></i> ' + result.data, {
          status: 'success'
        });
        $(row).fadeOut("slow", function(data) {
          row.remove();
          $('#challengeTable tbody').empty();
          $('#archiveTable tbody').empty();
          challengeList();
        });
      }).fail(function(data) {
        console.log("Error");
        console.log(data);
      });
    }
  </script>
</body>

</html>