<div class="topbar first">
  <nav class="uk-navbar uk-container">
    <div class="uk-navbar-brand">
      <svg class="site-navigation__logo" height="40px" version="1.1" viewBox="0 0 66 43" width="66px" x="0px" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" y="0px">
        <g class="rise-logo-el white">
        <path class="rise-logo" d="M14.1,22v-6.3c-0.5-0.1-0.9-0.1-1.5-0.1c-2,0-5.2,0.6-6.6,3.6v-3.4H0V39h6.2V28.4c0-5,2.8-6.5,6-6.5
              C12.8,21.8,13.4,21.9,14.1,22z"></path>
        <path class="rise-logo" d="M19,12c2.2,0,3.9-1.7,3.9-3.8c0-2.2-1.7-3.9-3.9-3.9c-2.1,0-3.9,1.7-3.9,3.9C15.1,10.3,16.9,12,19,12z"></path>
        <rect class="rise-logo" height="23.2" width="6.2" x="15.9" y="15.8"></rect>
        <path class="rise-logo" d="M42.5,32c0-3.4-2.3-6.2-6.8-7.1l-3.3-0.7c-1.3-0.2-2.1-0.9-2.1-2.1c0-1.3,1.3-2.3,3-2.3
              c2.6,0,3.6,1.7,3.8,3.1l5.2-1.2c-0.3-2.5-2.5-6.7-9-6.7c-5,0-8.6,3.4-8.6,7.6c0,3.3,2,5.9,6.5,6.9l3.1,0.7
              c1.8,0.4,2.5,1.2,2.5,2.3c0,1.2-1,2.3-3.1,2.3c-2.7,0-4.1-1.7-4.2-3.5L24,32.5c0.3,2.6,2.7,7.2,9.6,7.2
              C39.6,39.7,42.5,35.8,42.5,32z"></path>
        <path class="rise-logo" d="M50.4,38.5l4.3-4.3c-2.6-0.4-4.7-2.5-4.8-5.2h10l6.1-6.1c-1.4-4.9-5.2-7.8-10.9-7.8
              c-5.9,0-11.3,4.8-11.3,12.2C43.8,32.8,46.5,36.7,50.4,38.5z M55.2,20.2c3.6,0,5.1,2.3,5.2,4.6H50.1C50.2,22.6,52,20.2,55.2,20.2z"></path>
        </g>
      </svg>
    </div>
    <div class="uk-navbar-content uk-navbar-flip">
      <?php echo $_SESSION["user_name"] . ' (' . $_SESSION["user_group_name"] . ')' ?>
      <a class="uk-button uk-margin-left uk-margin-right" href="index.php?action=logout">Log out</a>
       <div id="sessionTimer">
         Time to Log Out: 
         <div id="clock"></div>
      </div>
    </div>
  </nav>  
</div>

<div class="topbar second">
  <nav class="uk-navbar uk-container">
    <ul class="uk-navbar-nav">
      <li><a href="stats.php">Stats</a></li>
      <?php if ($_SESSION["user_role"] == 'super_admin'): ?>
<!--       <li><a href="challenges.php">Challenges</a></li> -->
      <?php endif; ?>
      
      <?php if (($_SESSION["user_group"] == 4) || ($_SESSION["user_group"] == 5)): ?>
        <li><a href="responses.php?stage=3">Responses</a></li>
      <?php else: ?>      
        <li><a href="responses.php?stage=1">Responses</a></li>
      <?php endif; ?>
      
      <?php if (($_SESSION["user_group"] == 1)): ?>
        <li><a href="users.php">Users</a></li>
      <?php endif; ?>
    </ul>
  </nav>  
</div>

<script> 
  var user = '<?php echo $_SESSION["session_id"] ?>';
  var created = 1801;
  var minutes;
  var seconds;
  var left;
  var clock = document.getElementById('clock');
  updateClock();
  
  function updateClock() {
   
    created--;
        
    if (created == 300) {
      UIkit.notify('<i class="uk-icon-exclamation"></i> Your session will expire soon! <button id="extendSession" class="uk-button uk-button-primary uk-margin-top">Extend Session</button>', {timeout: 0});
    }
     if (created == 0) {
     window.location = "index.php?action=logout"
     }   
    minutes = Math.floor(created / 60);
    seconds = created - minutes * 60;
    
    if (seconds.toString().length == 1) {
      seconds = '0' + seconds;
    }
    if (seconds.toString().length < 1) {
      seconds = '00';
    }  
    if (minutes.toString().length == 1) {
      minutes = '0' + minutes;
    }
    if (minutes.toString().length < 1) {
      minutes = '00';
    }
    clock.innerHTML = minutes + ":" + seconds;
  }
  
  var timeinterval = setInterval(updateClock, 1000);
  
</script>