<?php
/**
 * Class H&H Auth
 *
 * Halcyon and Hijinks Auth appplication for login and logout.
 */
class HHAuth {

  // DB Connection Settings
  private $server = 'mysql:host=localhost;dbname=risehackathon';
  private $username = 'risehackathon';
  private $password = 'r@1s#hACkaTh0n';
  private $options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
  );

  // Database connection
  private $db_connection = null;

  // Login Status
  private $status = false;

  private $feedback = "";

  public function __construct() {
      if ($this->performMinimumRequirementsCheck()) {
          $this->runApplication();
      }
  }

  // Does checks for PHP version
  private function performMinimumRequirementsCheck() {
      if (version_compare(PHP_VERSION, '5.3.7', '<')) {
          echo "Sorry, Login Class does not not run on a PHP version older than 5.3.7 !";
      } elseif (version_compare(PHP_VERSION, '5.5.0', '<')) {
          require_once("password_compatibility_library.php");
          return true;
      } elseif (version_compare(PHP_VERSION, '5.5.0', '>=')) {
          return true;
      }
      // default return
      return false;
  }

  // Main controller that handles the flow of the application.
  public function runApplication() {
    // start the session, always needed!
    $this->startSession();
    // check for possible user interactions (login with session/post data or logout)
    $this->loginAction();
    // show "page", according to user's login status
    if ($this->getUserStatus()) {
      $this->authenticated();
    } else {
      $this->showLoginForm();
    }
  }

  // Connect to DB
  private function dbConnect() {
    try {
      $this->db_connection = new PDO($this->server, $this->username, $this->password, $this->options);
      return true;
    } catch (PDOException $e) {
      $this->feedback = "PDO database connection problem: " . $e->getMessage();
    } catch (Exception $e) {
      $this->feedback = "General problem: " . $e->getMessage();
    }
    return false;
  }

  // Handles the flow of the login process
  private function loginAction() {
    if (isset($_GET["action"]) && $_GET["action"] == "logout") {
      $this->logout();
    } elseif (!empty($_SESSION['user_name']) && ($_SESSION['auth_status'])) {
      $this->status = true;
    } elseif (isset($_POST["login"])) {
      $this->login();
    }
  }

  // Starts session
  private function startSession() {
    if (session_status() == PHP_SESSION_NONE) {
      session_set_cookie_params(60*60*24, "/form", "risehackathon.com");
      session_start();
      $_SESSION['created'] = time();
      $_SESSION['session_id'] = session_id();
    }
  }

  // Logs the user in
  private function login() {
    if ($this->validateInput()) {
      if ($this->dbConnect()) {
        $this->checkUser();
      }
    }
  }

  // Logs the user out
  private function logout() {
    $_SESSION = array();
    // Probably the same as above
    session_unset();
    session_destroy();
    $this->status = false;
  }

  // Validates user input
  private function validateInput() {
    if (!empty($_POST['user_name']) && !empty($_POST['user_password'])) {
      return true;
    }
    // default return
    return false;
  }

  // Checks if user exits
  private function checkUser() {
    $sql = 'SELECT users.user_id, users.user_name, users.user_email, users.user_password_hash, users.user_group, groups.group_name, users.user_role
            FROM users
            INNER JOIN groups
            ON users.user_group=groups.group_id
            WHERE users.user_name = :user_name OR users.user_email = :user_name
            LIMIT 1';

    $query = $this->db_connection->prepare($sql);
    $query->bindValue(':user_name', $_POST['user_name']);
    $query->execute();

    $result_row = $query->fetchObject();
    if ($result_row) {
        if (password_verify($_POST['user_password'], $result_row->user_password_hash)) {
            $_SESSION['user_id'] = $result_row->user_id;
            $_SESSION['user_name'] = $result_row->user_name;
            $_SESSION['user_email'] = $result_row->user_email;
            $_SESSION['auth_status'] = true;
            $_SESSION['user_role'] = $result_row->user_role;
            $_SESSION['user_group'] = $result_row->user_group;
            $_SESSION['user_group_name'] = $result_row->group_name;
            $this->status = true;
            return true;
        } else {
          // Wrong password
          $this->feedback = "Wrong password.";
        }
    } else {
      // User does not exist

      $this->feedback = "This user does not exist.";
    }
    // default return
    return false;
  }

  // Returns current status of the user
  public function getUserStatus() {
    return $this->status;
  }

  // Login Form
  private function showLoginForm() {
    if ($this->feedback) {
        echo $this->feedback . "<br/><br/>";
    }
    echo '<div id="login">';
    echo '<form method="post" class="uk-form" action="' . $_SERVER['SCRIPT_NAME'] . '" name="loginform"><fieldset>';
    echo '<div class="uk-form-row"><input id="login_input_username" type="text" name="user_name" placeholder="Username or Email" class="uk-form-large uk-width-1-5" required /></div>';
    echo '<div class="uk-form-row"><input id="login_input_password" type="password" name="user_password" placeholder="Password"class="uk-form-large uk-width-1-5"  required /></div>';
    echo '<div class="uk-form-row"><button type="submit" class="uk-button uk-button-primary uk-button-large uk-width-1-5" name="login" value="Log in">Log In</button></div>';
    echo '</fieldset></form>';
    echo '<p>Forgot your password? Email Hazel Fleming (<a href="mailto:hazel.fleming@barclays.com" target="_top">hazel.fleming@barclays.com</a>)<p>';
    echo '</div>';
  }

  // Login Area
  private function authenticated() {
    header('Location: ../admin/stats.php');
    echo $this->feedback;
  }

}

// run the application
$application = new HHAuth();
