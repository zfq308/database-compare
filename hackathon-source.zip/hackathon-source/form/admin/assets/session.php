<?php
session_start(); 

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1810)) {
    // last request was more than 30 minutes ago (10 seconds buffer)
    session_unset();     // unset $_SESSION variable for the run-time 
    session_destroy();   // destroy session data in storage
}

$_SESSION['last_activity'] = time(); // update last activity time stamp

if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} else if (time() - $_SESSION['created'] > 1800) {
    // session started more than 30 minutes ago
    session_regenerate_id(true);    // change session ID for the current session and invalidate old session ID
    $_SESSION['session_id'] = session_id();
    $_SESSION['created'] = time();  // update creation time
}

if(!isset($_SESSION["auth_status"]) OR !$_SESSION["auth_status"]) {
  echo 'Please <a href="index.php" target="_self">Log In</a> to view this page.';
  die;
}

// var_dump($_SESSION);