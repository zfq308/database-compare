var page = document.title.split("-").pop().toLowerCase().replace(/\s+/g, '');

$('.topbar.second:not(.addon) .uk-navbar-nav > li').each(function(index) {
  if ($(this).children('a').attr('href').substr(0, $(this).children('a').attr('href').indexOf('.')) == page) {
    $(this).addClass('uk-active');
  }
});

$('body').on('click', '#extendSession', function(e) {
	extendSession();
});

function extendSession() {
  $.ajax({
    method: "POST",
    url: "../api.php",
    dataType: "json",
    data: {
      cmd: "extendSession",
			user: user
    },
    error: function(data) {
      console.log("Error");
      console.log(data);
    },
    success: function(data) {
			UIkit.notify('<i class="uk-icon-check"></i> '+data.data , {status:'success'});
			created = 1801;
			updateClock();
    }
  });
}

function getUrlParameter(sParam) {
  var sPageURL = decodeURIComponent(window.location.search.substring(1)),
    sURLVariables = sPageURL.split('&'),
    sParameterName,
    i;

  for (i = 0; i < sURLVariables.length; i++) {
    sParameterName = sURLVariables[i].split('=');

    if (sParameterName[0] === sParam) {
      return sParameterName[1] === undefined ? true : sParameterName[1];
    }
  }
}

function parseDate(input, type) {
  var parts = input.split('-');
  var date = new Date(parts[0], parts[1] - 1, parts[2]); // Note: months are 0-based
  
  if (type == 'formatted') {
    date = ('0' + date.getDate()).slice(-2) + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' +   date.getFullYear();
  }
  return date;
}

function readURL(files) {
  if (files && files[0]) {
    input = files[0];

    var reader = new FileReader();

    reader.onload = function(e) {

      if (input.type.indexOf("image") >= 0) {
        $('#slider-list').append('<li data-name="' + input.name + '" data-type="image" data-size="' + (input.size / (1024 * 1024)).toFixed(2) + '"><button class="uk-button uk-button-danger uk-button-large slider-remove-button" data-uk-tooltip title="Click to remove Item"><i class="uk-icon-trash-o"></i></button><div class="slider-image-preview"><img src="' + e.target.result + '"><div class="slider-image-preview-details uk-clearfix"><span class="uk-float-left">' + input.name + '</span><span class="uk-float-right">' + (input.size / (1024 * 1024)).toFixed(2) + ' MB</span></div></div></li>');
      }

      if (input.type.indexOf("video") >= 0) {
        $('#slider-list').append('<li data-name="' + input.name + '" data-type="video" data-size="' + (input.size / (1024 * 1024)).toFixed(2) + '"><button class="uk-button uk-button-danger uk-button-large slider-remove-button" data-uk-tooltip title="Click to remove Item"><i class="uk-icon-trash-o"></i></button><div class="slider-image-preview"><video src="' + e.target.result + '" class="uk-responsive-width">Your browser does not support the video tag.</video><div class="slider-image-preview-details uk-clearfix"><span class="uk-float-left">' + input.name + '</span><span class="uk-float-right">' + (input.size / (1024 * 1024)).toFixed(2) + ' MB</span></div></div></li>');
      }

    }

    reader.readAsDataURL(input);
    $('#slider-upload-button').blur();
  }
}

function xmlToJson(xml) {
	
	// Create the return object
	var obj = {};

	if (xml.nodeType == 1) { // element
		// do attributes
		if (xml.attributes.length > 0) {
		obj["@attributes"] = {};
			for (var j = 0; j < xml.attributes.length; j++) {
				var attribute = xml.attributes.item(j);
				obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
			}
		}
	} else if (xml.nodeType == 3) { // text
		obj = xml.nodeValue;
	}

	// do children
	if (xml.hasChildNodes()) {
		for(var i = 0; i < xml.childNodes.length; i++) {
			var item = xml.childNodes.item(i);
			var nodeName = item.nodeName;
			if (typeof(obj[nodeName]) == "undefined") {
				obj[nodeName] = xmlToJson(item);
			} else {
				if (typeof(obj[nodeName].push) == "undefined") {
					var old = obj[nodeName];
					obj[nodeName] = [];
					obj[nodeName].push(old);
				}
				obj[nodeName].push(xmlToJson(item));
			}
		}
	}
	return obj;
}

function pushResponse(stage, id, origin) {
	var element = '';
	
	if (origin == 'list') {
		element = $('.response-row[data-id="' + id + '"]');
	}
	
	if (origin == 'single') {
		element = $('#stage');
	}
	
	var confirm = false;

	UIkit.modal.confirm("Are you sure?", function() {

		$.ajax({
			method: "POST",
			url: "../api.php",
			dataType: "json",
			data: {
				cmd: "pushResponse",
				data: stage + ',' + id,
				user: user
			},
			error: function(data) {
				console.log("Error");
				console.log(data);
			},
			success: function(data) {
				UIkit.notify('<i class="uk-icon-check"></i> ' + data.data, {
					status: 'success'
				});
				
				if (origin == 'list') {
					$(element).fadeOut("slow", function() {
						element.remove();
					});
				}
				
				if (origin == 'single') {
      		location.reload();
				}
			}
		});
	});
}