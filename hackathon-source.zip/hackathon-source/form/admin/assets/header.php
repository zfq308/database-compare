<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.25.0/css/uikit.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/2.26.1/css/components/notify.almost-flat.min.css" />
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
