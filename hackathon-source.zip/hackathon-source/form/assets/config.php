<?php
$db = new PDO('mysql:host=localhost;dbname=risehackathon;charset=utf8', 'risehackathon', 'r@1s#hACkaTh0n');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
